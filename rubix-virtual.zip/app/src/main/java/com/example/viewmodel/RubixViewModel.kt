package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.RubixApplication
import com.example.data.local.entity.VirtualAppEntity
import com.example.data.local.entity.VirtualFileEntity
import com.example.data.local.entity.VirtualInstanceEntity
import com.example.data.local.entity.VirtualSnapshotEntity
import com.example.data.model.CompatibilityReport
import com.example.data.model.PerformanceMode
import com.example.data.model.SystemResourceStats
import com.example.domain.ApkInstallResult
import com.example.domain.HardwareCompatibilityChecker
import com.example.domain.VirtualEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab {
    HOME,
    VIRTUAL_ANDROID,
    FILES,
    TOOLS,
    SETTINGS
}

enum class GuestDisplayMode {
    FULLSCREEN,
    FLOATING_WINDOW,
    MINIMIZED
}

data class TransferProgressState(
    val isTransferring: Boolean = false,
    val fileName: String = "",
    val progress: Float = 0f,
    val speedKbps: Double = 0.0,
    val direction: String = "IMPORT" // IMPORT or EXPORT
)

data class TerminalLine(
    val text: String,
    val isInput: Boolean = false,
    val isError: Boolean = false
)

class RubixViewModel(application: Application) : AndroidViewModel(application) {

    private val virtualEngine: VirtualEngine = (application as RubixApplication).virtualEngine

    private val _compatibilityReport = MutableStateFlow<CompatibilityReport?>(null)
    val compatibilityReport: StateFlow<CompatibilityReport?> = _compatibilityReport.asStateFlow()

    private val _hasCompletedWelcome = MutableStateFlow(false)
    val hasCompletedWelcome: StateFlow<Boolean> = _hasCompletedWelcome.asStateFlow()

    private val _selectedTab = MutableStateFlow(MainTab.HOME)
    val selectedTab: StateFlow<MainTab> = _selectedTab.asStateFlow()

    private val _selectedInstanceId = MutableStateFlow<String?>(null)
    val selectedInstanceId: StateFlow<String?> = _selectedInstanceId.asStateFlow()

    val instances: StateFlow<List<VirtualInstanceEntity>> = virtualEngine.instanceDao.getAllInstances()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentInstance: StateFlow<VirtualInstanceEntity?> = combine(instances, _selectedInstanceId) { list, id ->
        if (id != null) list.find { it.id == id } else list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _currentInstanceApps = MutableStateFlow<List<VirtualAppEntity>>(emptyList())
    val currentInstanceApps: StateFlow<List<VirtualAppEntity>> = _currentInstanceApps.asStateFlow()

    private val _currentInstanceFiles = MutableStateFlow<List<VirtualFileEntity>>(emptyList())
    val currentInstanceFiles: StateFlow<List<VirtualFileEntity>> = _currentInstanceFiles.asStateFlow()

    private val _currentInstanceSnapshots = MutableStateFlow<List<VirtualSnapshotEntity>>(emptyList())
    val currentInstanceSnapshots: StateFlow<List<VirtualSnapshotEntity>> = _currentInstanceSnapshots.asStateFlow()

    val bootLogs: StateFlow<List<String>> = virtualEngine.bootLogs
    val bootProgress: StateFlow<Float> = virtualEngine.bootProgress
    val isBooting: StateFlow<Boolean> = virtualEngine.isBooting
    val activeApp: StateFlow<VirtualAppEntity?> = virtualEngine.activeApp
    val recentApps: StateFlow<List<VirtualAppEntity>> = virtualEngine.recentApps
    val resourceStats: StateFlow<SystemResourceStats> = virtualEngine.resourceStats

    // Display & Windowing
    private val _displayMode = MutableStateFlow(GuestDisplayMode.FULLSCREEN)
    val displayMode: StateFlow<GuestDisplayMode> = _displayMode.asStateFlow()

    private val _isQuickSettingsOpen = MutableStateFlow(false)
    val isQuickSettingsOpen: StateFlow<Boolean> = _isQuickSettingsOpen.asStateFlow()

    private val _isRecentAppsOpen = MutableStateFlow(false)
    val isRecentAppsOpen: StateFlow<Boolean> = _isRecentAppsOpen.asStateFlow()

    private val _isAppDrawerOpen = MutableStateFlow(false)
    val isAppDrawerOpen: StateFlow<Boolean> = _isAppDrawerOpen.asStateFlow()

    // File transfer state
    private val _transferState = MutableStateFlow(TransferProgressState())
    val transferState: StateFlow<TransferProgressState> = _transferState.asStateFlow()

    // Terminal state
    private val _terminalLines = MutableStateFlow<List<TerminalLine>>(
        listOf(
            TerminalLine("RUBIX VIRTUAL - Android 12 Guest Shell (toybox 0.8.4)"),
            TerminalLine("Architecture: aarch64-virtual | Linux 5.10.136-android12-9-g3918a"),
            TerminalLine("Type 'help' for command list or 'su' for virtual root privileges.")
        )
    )
    val terminalLines: StateFlow<List<TerminalLine>> = _terminalLines.asStateFlow()

    // Status Message / Toast feedback
    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    init {
        runCompatibilityCheck()
        viewModelScope.launch {
            val def = virtualEngine.createDefaultInstanceIfNone()
            _selectedInstanceId.value = def.id
            observeInstanceData(def.id)
        }
    }

    private fun observeInstanceData(instanceId: String) {
        viewModelScope.launch {
            virtualEngine.appDao.getAppsByInstance(instanceId).collect { apps ->
                _currentInstanceApps.value = apps
            }
        }
        viewModelScope.launch {
            virtualEngine.fileDao.getFilesByInstance(instanceId).collect { files ->
                _currentInstanceFiles.value = files
            }
        }
        viewModelScope.launch {
            virtualEngine.snapshotDao.getSnapshotsByInstance(instanceId).collect { snaps ->
                _currentInstanceSnapshots.value = snaps
            }
        }
    }

    fun selectTab(tab: MainTab) {
        _selectedTab.value = tab
    }

    fun setDisplayMode(mode: GuestDisplayMode) {
        _displayMode.value = mode
    }

    fun selectInstance(id: String) {
        _selectedInstanceId.value = id
        observeInstanceData(id)
    }

    fun runCompatibilityCheck() {
        val report = HardwareCompatibilityChecker.checkCompatibility(getApplication<Application>())
        _compatibilityReport.value = report
    }

    fun completeWelcome() {
        _hasCompletedWelcome.value = true
    }

    fun showWelcomeAgain() {
        _hasCompletedWelcome.value = false
    }

    fun startCurrentInstance() {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            _selectedTab.value = MainTab.VIRTUAL_ANDROID
            virtualEngine.startInstance(inst.id)
        }
    }

    fun stopCurrentInstance() {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.stopInstance(inst.id)
            _isRecentAppsOpen.value = false
            _isAppDrawerOpen.value = false
            _isQuickSettingsOpen.value = false
        }
    }

    fun toggleVirtualRoot() {
        val inst = currentInstance.value ?: return
        val newRoot = !inst.virtualRootEnabled
        viewModelScope.launch {
            virtualEngine.instanceDao.updateVirtualRoot(inst.id, newRoot)
            _terminalLines.value = _terminalLines.value + TerminalLine(
                "[SYSTEM] Virtual Root state updated to: ${if (newRoot) "ENABLED (UID 0)" else "DISABLED (UID 1000)"}"
            )
        }
    }

    fun setPerformanceMode(mode: PerformanceMode) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.instanceDao.updatePerformanceMode(inst.id, mode.name)
        }
    }

    fun setWallpaper(index: Int) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.instanceDao.updateWallpaper(inst.id, index)
        }
    }

    fun createInstance(name: String, ramMb: Int, cpuCores: Int, storageGb: Int, root: Boolean) {
        viewModelScope.launch {
            val newInst = virtualEngine.createNewInstance(name, ramMb, cpuCores, storageGb, root)
            selectInstance(newInst.id)
            showBanner("Virtual instance '${newInst.name}' created successfully.")
        }
    }

    fun cloneCurrentInstance(newName: String) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            val cloned = virtualEngine.cloneInstance(inst.id, newName)
            if (cloned != null) {
                selectInstance(cloned.id)
                showBanner("Cloned '${inst.name}' -> '${cloned.name}'")
            }
        }
    }

    fun deleteCurrentInstance() {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.deleteInstance(inst.id)
            val remaining = instances.value.filter { it.id != inst.id }
            if (remaining.isNotEmpty()) {
                selectInstance(remaining.first().id)
            } else {
                val def = virtualEngine.createDefaultInstanceIfNone()
                selectInstance(def.id)
            }
            showBanner("Instance deleted.")
        }
    }

    fun createSnapshot(name: String, description: String) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.createSnapshot(inst.id, name, description)
            showBanner("Snapshot '$name' captured successfully.")
        }
    }

    fun restoreSnapshot(snapshot: VirtualSnapshotEntity) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.restoreSnapshot(inst.id, snapshot.id)
            showBanner("Instance restored to snapshot '${snapshot.name}'.")
        }
    }

    fun deleteSnapshot(snapshot: VirtualSnapshotEntity) {
        viewModelScope.launch {
            virtualEngine.deleteSnapshot(snapshot.id)
            showBanner("Snapshot deleted.")
        }
    }

    // App Execution
    fun launchApp(app: VirtualAppEntity) {
        _isAppDrawerOpen.value = false
        _isRecentAppsOpen.value = false
        _isQuickSettingsOpen.value = false
        virtualEngine.launchApp(app)
    }

    fun closeActiveApp() {
        virtualEngine.closeActiveApp()
    }

    fun toggleRecentApps() {
        _isRecentAppsOpen.value = !_isRecentAppsOpen.value
        _isAppDrawerOpen.value = false
        _isQuickSettingsOpen.value = false
    }

    fun closeRecentApps() {
        _isRecentAppsOpen.value = false
    }

    fun toggleAppDrawer() {
        _isAppDrawerOpen.value = !_isAppDrawerOpen.value
        _isRecentAppsOpen.value = false
        _isQuickSettingsOpen.value = false
    }

    fun closeAppDrawer() {
        _isAppDrawerOpen.value = false
    }

    fun toggleQuickSettings() {
        _isQuickSettingsOpen.value = !_isQuickSettingsOpen.value
    }

    fun closeQuickSettings() {
        _isQuickSettingsOpen.value = false
    }

    fun clearAllRecentApps() {
        virtualEngine.clearRecentApps()
        _isRecentAppsOpen.value = false
    }

    fun removeRecentApp(app: VirtualAppEntity) {
        virtualEngine.removeRecentApp(app)
    }

    // App Management
    fun forceStopApp(app: VirtualAppEntity) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.packageManager.forceStopApp(inst.id, app.packageName)
            virtualEngine.removeRecentApp(app)
            showBanner("Force stopped ${app.appName}")
        }
    }

    fun clearAppCache(app: VirtualAppEntity) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.packageManager.clearAppCache(inst.id, app.packageName)
            showBanner("Cache cleared for ${app.appName}")
        }
    }

    fun clearAppData(app: VirtualAppEntity) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.packageManager.clearAppData(inst.id, app.packageName)
            showBanner("User data reset for ${app.appName}")
        }
    }

    fun uninstallApp(app: VirtualAppEntity) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            val ok = virtualEngine.packageManager.uninstallApp(inst.id, app.packageName)
            if (ok) {
                virtualEngine.removeRecentApp(app)
                showBanner("Uninstalled ${app.appName}")
            } else {
                showBanner("Cannot uninstall protected system package.")
            }
        }
    }

    fun toggleAppRootPermission(app: VirtualAppEntity) {
        val inst = currentInstance.value ?: return
        val newGranted = !app.rootAccessGranted
        viewModelScope.launch {
            virtualEngine.packageManager.setRootPermission(inst.id, app.packageName, newGranted)
            showBanner("Virtual Root ${if (newGranted) "GRANTED" else "REVOKED"} for ${app.appName}")
        }
    }

    // APK Installation
    fun installSampleApk(name: String, pkg: String, version: String, icon: String, sizeMb: Double) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            val res = virtualEngine.packageManager.installApk(
                instanceId = inst.id,
                appName = name,
                packageName = pkg,
                versionName = version,
                versionCode = 1,
                apkPath = "/data/app/$pkg.apk",
                sizeMb = sizeMb,
                iconKey = icon
            )
            when (res) {
                is ApkInstallResult.Success -> showBanner("APK installed successfully: $name ($pkg)")
                is ApkInstallResult.Error -> showBanner("Install error: ${res.reason}")
            }
        }
    }

    fun installImportedApk(name: String, pkg: String, sizeMb: Double) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            val res = virtualEngine.packageManager.installApk(
                instanceId = inst.id,
                appName = name,
                packageName = pkg,
                versionName = "1.0.0",
                versionCode = 1,
                apkPath = "/data/app/$pkg.apk",
                sizeMb = sizeMb,
                iconKey = "custom"
            )
            when (res) {
                is ApkInstallResult.Success -> showBanner("Successfully installed: $name")
                is ApkInstallResult.Error -> showBanner("Error: ${res.reason}")
            }
        }
    }

    // File Management
    fun createVirtualFolder(parentPath: String, name: String) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            val ok = virtualEngine.fileSystem.createFolder(inst.id, parentPath, name)
            if (ok) showBanner("Folder '$name' created.")
            else showBanner("Folder already exists.")
        }
    }

    fun createVirtualTextFile(parentPath: String, name: String, content: String) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.fileSystem.createFile(
                instanceId = inst.id,
                parentPath = parentPath,
                fileName = name,
                content = content,
                sizeBytes = content.toByteArray().size.toLong(),
                mimeType = "text/plain"
            )
            showBanner("File '$name' saved.")
        }
    }

    fun deleteVirtualFile(file: VirtualFileEntity) {
        val inst = currentInstance.value ?: return
        viewModelScope.launch {
            virtualEngine.fileSystem.deleteFileOrFolder(inst.id, file)
            showBanner("Deleted ${file.name}")
        }
    }

    // Host ↔ Guest Transfer
    fun simulateFileTransfer(fileName: String, isImport: Boolean, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _transferState.value = TransferProgressState(
                isTransferring = true,
                fileName = fileName,
                progress = 0.05f,
                speedKbps = 2450.0,
                direction = if (isImport) "IMPORT (Host → Guest)" else "EXPORT (Guest → Host)"
            )
            for (step in 1..10) {
                kotlinx.coroutines.delay(180)
                _transferState.value = _transferState.value.copy(
                    progress = step / 10f,
                    speedKbps = (2200..3400).random().toDouble()
                )
            }
            _transferState.value = TransferProgressState(isTransferring = false)
            showBanner("${if (isImport) "Imported" else "Exported"} '$fileName' successfully.")
            onComplete()
        }
    }

    // Terminal Commands
    fun executeTerminalCommand(input: String) {
        val inst = currentInstance.value ?: return
        val prompt = virtualEngine.terminalEngine.getPrompt(inst.virtualRootEnabled)
        val trimmed = input.trim()

        if (trimmed.equals("clear", ignoreCase = true)) {
            _terminalLines.value = listOf(
                TerminalLine("RUBIX VIRTUAL - Android 12 Guest Shell (toybox 0.8.4)"),
                TerminalLine("Virtual Root: ${if (inst.virtualRootEnabled) "ENABLED (UID 0)" else "DISABLED (UID 1000)"}")
            )
            return
        }

        val output = virtualEngine.terminalEngine.executeCommand(trimmed, inst.virtualRootEnabled)
        val newLines = _terminalLines.value.toMutableList()
        newLines.add(TerminalLine("$prompt$trimmed", isInput = true))
        if (output.isNotBlank()) {
            newLines.add(TerminalLine(output, isError = output.contains("Permission denied") || output.contains("not found")))
        }
        _terminalLines.value = newLines
    }

    fun showBanner(msg: String) {
        _statusBannerMessage.value = msg
        viewModelScope.launch {
            kotlinx.coroutines.delay(3500)
            if (_statusBannerMessage.value == msg) {
                _statusBannerMessage.value = null
            }
        }
    }

    fun dismissBanner() {
        _statusBannerMessage.value = null
    }
}
