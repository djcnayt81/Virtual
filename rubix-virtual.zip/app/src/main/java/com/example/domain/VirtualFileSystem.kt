package com.example.domain

import com.example.data.local.dao.VirtualFileDao
import com.example.data.local.entity.VirtualFileEntity
import java.util.UUID

class VirtualFileSystem(private val fileDao: VirtualFileDao) {

    suspend fun initializeDefaultFileSystem(instanceId: String) {
        val defaultDirs = listOf(
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Android",
                name = "Android",
                isDirectory = true,
                mimeType = "inode/directory"
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/DCIM",
                name = "DCIM",
                isDirectory = true,
                mimeType = "inode/directory"
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/DCIM/Camera",
                name = "Camera",
                isDirectory = true,
                mimeType = "inode/directory"
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Download",
                name = "Download",
                isDirectory = true,
                mimeType = "inode/directory"
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Music",
                name = "Music",
                isDirectory = true,
                mimeType = "inode/directory"
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Movies",
                name = "Movies",
                isDirectory = true,
                mimeType = "inode/directory"
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Pictures",
                name = "Pictures",
                isDirectory = true,
                mimeType = "inode/directory"
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Documents",
                name = "Documents",
                isDirectory = true,
                mimeType = "inode/directory"
            ),
            // Default sample documents & files
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Documents/Welcome_Android12.txt",
                name = "Welcome_Android12.txt",
                isDirectory = false,
                sizeBytes = 1024,
                mimeType = "text/plain",
                textContent = "Welcome to RUBIX VIRTUAL - Android 12 Environment.\n\nRunning fully isolated on your host device with zero Wi-Fi debugging requirements.\nVirtual Root: Available in Guest Terminal & Settings.\nStorage: Independent Sandboxed Flash File System."
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Download/rubix_tools_guide.pdf",
                name = "rubix_tools_guide.pdf",
                isDirectory = false,
                sizeBytes = 245760,
                mimeType = "application/pdf",
                textContent = "RUBIX VIRTUAL Architecture & User Guide"
            ),
            VirtualFileEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                path = "/storage/emulated/0/Music/cyber_pulse_synth.mp3",
                name = "cyber_pulse_synth.mp3",
                isDirectory = false,
                sizeBytes = 3450000,
                mimeType = "audio/mpeg"
            )
        )

        fileDao.insertFiles(defaultDirs)
    }

    suspend fun createFolder(instanceId: String, parentPath: String, folderName: String): Boolean {
        val cleanParent = if (parentPath.endsWith("/")) parentPath.dropLast(1) else parentPath
        val fullPath = "$cleanParent/$folderName"
        val existing = fileDao.getFileByPath(instanceId, fullPath)
        if (existing != null) return false

        val entity = VirtualFileEntity(
            id = UUID.randomUUID().toString(),
            instanceId = instanceId,
            path = fullPath,
            name = folderName,
            isDirectory = true,
            mimeType = "inode/directory"
        )
        fileDao.insertFile(entity)
        return true
    }

    suspend fun createFile(
        instanceId: String,
        parentPath: String,
        fileName: String,
        content: String?,
        sizeBytes: Long,
        mimeType: String,
        localUri: String? = null
    ): Boolean {
        val cleanParent = if (parentPath.endsWith("/")) parentPath.dropLast(1) else parentPath
        val fullPath = "$cleanParent/$fileName"
        val entity = VirtualFileEntity(
            id = UUID.randomUUID().toString(),
            instanceId = instanceId,
            path = fullPath,
            name = fileName,
            isDirectory = false,
            sizeBytes = sizeBytes,
            mimeType = mimeType,
            textContent = content,
            localUri = localUri
        )
        fileDao.insertFile(entity)
        return true
    }

    suspend fun deleteFileOrFolder(instanceId: String, file: VirtualFileEntity) {
        fileDao.deleteById(instanceId, file.id)
    }

    suspend fun rename(instanceId: String, file: VirtualFileEntity, newName: String): Boolean {
        val parent = file.path.substringBeforeLast('/', "")
        val newPath = if (parent.isEmpty()) "/$newName" else "$parent/$newName"
        fileDao.updateFile(file.copy(name = newName, path = newPath, lastModified = System.currentTimeMillis()))
        return true
    }
}
