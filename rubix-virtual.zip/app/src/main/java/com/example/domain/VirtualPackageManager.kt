package com.example.domain

import com.example.data.local.dao.VirtualAppDao
import com.example.data.local.entity.VirtualAppEntity
import java.util.UUID

sealed class ApkInstallResult {
    data class Success(val app: VirtualAppEntity) : ApkInstallResult()
    data class Error(val reason: String, val suggestedSolution: String) : ApkInstallResult()
}

class VirtualPackageManager(private val appDao: VirtualAppDao) {

    suspend fun initializeDefaultSystemApps(instanceId: String) {
        val systemApps = listOf(
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.settings",
                appName = "Settings",
                versionName = "12.0.0_r34",
                versionCode = 31,
                iconKey = "settings",
                isSystemApp = true,
                dataSizeMb = 18.4,
                cacheSizeMb = 2.1,
                grantedPermissions = "SYSTEM_SETTINGS,ROOT,STORAGE,NETWORK"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.documentsui",
                appName = "Files",
                versionName = "12.0.0",
                versionCode = 31,
                iconKey = "files",
                isSystemApp = true,
                dataSizeMb = 12.0,
                cacheSizeMb = 1.5,
                grantedPermissions = "READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,MANAGE_DOCUMENTS"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.browser",
                appName = "Browser",
                versionName = "12.2.1",
                versionCode = 31,
                iconKey = "browser",
                isSystemApp = true,
                dataSizeMb = 24.5,
                cacheSizeMb = 8.7,
                grantedPermissions = "INTERNET,ACCESS_NETWORK_STATE,DOWNLOAD_WITHOUT_NOTIFICATION"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.camera2",
                appName = "Camera",
                versionName = "12.0.0",
                versionCode = 31,
                iconKey = "camera",
                isSystemApp = true,
                dataSizeMb = 8.2,
                cacheSizeMb = 0.8,
                grantedPermissions = "CAMERA,RECORD_AUDIO,WRITE_EXTERNAL_STORAGE"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.gallery3d",
                appName = "Gallery",
                versionName = "12.0.0",
                versionCode = 31,
                iconKey = "gallery",
                isSystemApp = true,
                dataSizeMb = 14.8,
                cacheSizeMb = 5.2,
                grantedPermissions = "READ_EXTERNAL_STORAGE,ACCESS_MEDIA_LOCATION"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.rubix.terminal",
                appName = "Terminal & Su",
                versionName = "3.4.0",
                versionCode = 34,
                iconKey = "terminal",
                isSystemApp = true,
                dataSizeMb = 6.4,
                cacheSizeMb = 0.4,
                grantedPermissions = "VIRTUAL_ROOT,SYSTEM_EXEC,TERMINAL_IO",
                rootAccessGranted = true
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.music",
                appName = "Music",
                versionName = "12.0.0",
                versionCode = 31,
                iconKey = "music",
                isSystemApp = true,
                dataSizeMb = 9.1,
                cacheSizeMb = 1.2,
                grantedPermissions = "READ_EXTERNAL_STORAGE,AUDIO_OUTPUT"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.calculator2",
                appName = "Calculator",
                versionName = "12.0.0",
                versionCode = 31,
                iconKey = "calculator",
                isSystemApp = true,
                dataSizeMb = 3.2,
                cacheSizeMb = 0.1,
                grantedPermissions = "NONE"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.notes",
                appName = "Notes",
                versionName = "12.1.0",
                versionCode = 31,
                iconKey = "notes",
                isSystemApp = true,
                dataSizeMb = 4.5,
                cacheSizeMb = 0.3,
                grantedPermissions = "STORAGE"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.deskclock",
                appName = "Clock",
                versionName = "12.0.0",
                versionCode = 31,
                iconKey = "clock",
                isSystemApp = true,
                dataSizeMb = 5.0,
                cacheSizeMb = 0.2,
                grantedPermissions = "SCHEDULE_EXACT_ALARM,VIBRATE"
            ),
            VirtualAppEntity(
                id = UUID.randomUUID().toString(),
                instanceId = instanceId,
                packageName = "com.android.packageinstaller",
                appName = "Package Installer",
                versionName = "12.0.0",
                versionCode = 31,
                iconKey = "packageinstaller",
                isSystemApp = true,
                dataSizeMb = 7.3,
                cacheSizeMb = 0.9,
                grantedPermissions = "INSTALL_PACKAGES,DELETE_PACKAGES"
            )
        )

        appDao.insertApps(systemApps)
    }

    suspend fun installApk(
        instanceId: String,
        appName: String,
        packageName: String,
        versionName: String,
        versionCode: Int,
        apkPath: String,
        sizeMb: Double = 25.0,
        iconKey: String = "custom",
        declaredPermissions: String = "INTERNET,ACCESS_NETWORK_STATE,READ_EXTERNAL_STORAGE"
    ): ApkInstallResult {
        // Validation checks
        if (packageName.isBlank() || !packageName.contains(".")) {
            return ApkInstallResult.Error(
                reason = "Invalid package naming in APK manifest.",
                suggestedSolution = "Ensure APK follows reverse-DNS package naming format."
            )
        }

        val existing = appDao.getApp(instanceId, packageName)
        if (existing != null && existing.isSystemApp) {
            return ApkInstallResult.Error(
                reason = "Cannot overwrite core Android 12 system package.",
                suggestedSolution = "Use a custom package namespace."
            )
        }

        val appEntity = VirtualAppEntity(
            id = UUID.randomUUID().toString(),
            instanceId = instanceId,
            packageName = packageName,
            appName = appName,
            versionName = versionName,
            versionCode = versionCode,
            iconKey = iconKey,
            isSystemApp = false,
            apkPath = apkPath,
            dataSizeMb = sizeMb,
            cacheSizeMb = 0.0,
            grantedPermissions = declaredPermissions,
            rootAccessGranted = false,
            installedAt = System.currentTimeMillis()
        )

        appDao.insertApp(appEntity)
        return ApkInstallResult.Success(appEntity)
    }

    suspend fun uninstallApp(instanceId: String, packageName: String): Boolean {
        val app = appDao.getApp(instanceId, packageName) ?: return false
        if (app.isSystemApp) return false // Protect system apps
        appDao.deleteApp(instanceId, packageName)
        return true
    }

    suspend fun forceStopApp(instanceId: String, packageName: String) {
        appDao.setAppRunning(instanceId, packageName, false)
    }

    suspend fun clearAppCache(instanceId: String, packageName: String) {
        appDao.clearAppCache(instanceId, packageName)
    }

    suspend fun clearAppData(instanceId: String, packageName: String) {
        appDao.clearAppData(instanceId, packageName)
    }

    suspend fun setRootPermission(instanceId: String, packageName: String, granted: Boolean) {
        appDao.updateRootPermission(instanceId, packageName, granted)
    }

    suspend fun setPermissions(instanceId: String, packageName: String, permissions: String) {
        appDao.updatePermissions(instanceId, packageName, permissions)
    }
}
