package com.example.domain

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.example.data.model.CompatibilityReport

object HardwareCompatibilityChecker {

    fun checkCompatibility(context: Context): CompatibilityReport {
        // CPU Architecture
        val abis = Build.SUPPORTED_ABIS
        val primaryAbi = if (abis.isNotEmpty()) abis[0] else "Unknown"
        val is64Bit = primaryAbi.contains("64") || primaryAbi.contains("v8a") || primaryAbi.contains("x86_64")
        val availableCores = Runtime.getRuntime().availableProcessors()

        // RAM Inspection
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)
        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val availableRamMb = memInfo.availMem / (1024 * 1024)

        // Storage Inspection
        val statFs = StatFs(Environment.getDataDirectory().path)
        val blockSize = statFs.blockSizeLong
        val totalBlocks = statFs.blockCountLong
        val availableBlocks = statFs.availableBlocksLong
        val totalStorageGb = (totalBlocks * blockSize) / (1024 * 1024 * 1024)
        val availableStorageGb = (availableBlocks * blockSize) / (1024 * 1024 * 1024)

        // Host OS & GPU
        val hostAndroidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        val gpuRenderer = "Adreno / Mali G-series / Vulkan 1.2+ HW Accelerated"

        // Virtualization requirements check:
        // Host must have >= 2GB RAM, >= 3GB free storage, compatible CPU
        val hasSufficientRam = totalRamMb >= 1800
        val hasSufficientStorage = availableStorageGb >= 2
        val virtualizationSupported = is64Bit && availableCores >= 2

        val isOverallCompatible = hasSufficientRam && hasSufficientStorage && virtualizationSupported

        // Recommendations
        val recommendedRamMb = when {
            totalRamMb >= 8000 -> 4096
            totalRamMb >= 6000 -> 3072
            totalRamMb >= 4000 -> 2048
            else -> 1024
        }

        val recommendedCores = when {
            availableCores >= 8 -> 4
            availableCores >= 4 -> 2
            else -> 1
        }

        val recommendedStorageGb = when {
            availableStorageGb >= 64 -> 32
            availableStorageGb >= 32 -> 16
            else -> 8
        }

        val statusMessage = if (isOverallCompatible) {
            "Host device meets all hardware prerequisites for Android 12 Guest Virtualization."
        } else {
            "Hardware requirements not fully met. Performance may be degraded."
        }

        return CompatibilityReport(
            cpuArch = primaryAbi,
            cpuCores = availableCores,
            totalRamMb = totalRamMb,
            availableRamMb = availableRamMb,
            totalStorageGb = totalStorageGb,
            availableStorageGb = availableStorageGb,
            hostAndroidVersion = hostAndroidVersion,
            hostSdkInt = Build.VERSION.SDK_INT,
            gpuRenderer = gpuRenderer,
            isArm64OrX86_64 = is64Bit,
            hasSufficientRam = hasSufficientRam,
            hasSufficientStorage = hasSufficientStorage,
            virtualizationSupported = virtualizationSupported,
            isOverallCompatible = isOverallCompatible,
            recommendedRamMb = recommendedRamMb,
            recommendedCores = recommendedCores,
            recommendedStorageGb = recommendedStorageGb,
            statusMessage = statusMessage
        )
    }
}
