package com.example.domain

import android.content.Context
import com.example.data.local.RubixDatabase
import com.example.data.local.entity.VirtualAppEntity
import com.example.data.local.entity.VirtualFileEntity
import com.example.data.local.entity.VirtualInstanceEntity
import com.example.data.local.entity.VirtualSnapshotEntity
import com.example.data.model.SystemResourceStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

class VirtualEngine(private val context: Context) {

    private val db = RubixDatabase.getDatabase(context)
    val instanceDao = db.instanceDao()
    val appDao = db.appDao()
    val fileDao = db.fileDao()
    val snapshotDao = db.snapshotDao()

    val fileSystem = VirtualFileSystem(fileDao)
    val packageManager = VirtualPackageManager(appDao)
    val terminalEngine = VirtualTerminalEngine()

    private val _bootLogs = MutableStateFlow<List<String>>(emptyList())
    val bootLogs: StateFlow<List<String>> = _bootLogs.asStateFlow()

    private val _bootProgress = MutableStateFlow(0f)
    val bootProgress: StateFlow<Float> = _bootProgress.asStateFlow()

    private val _isBooting = MutableStateFlow(false)
    val isBooting: StateFlow<Boolean> = _isBooting.asStateFlow()

    private val _activeApp = MutableStateFlow<VirtualAppEntity?>(null)
    val activeApp: StateFlow<VirtualAppEntity?> = _activeApp.asStateFlow()

    private val _recentApps = MutableStateFlow<List<VirtualAppEntity>>(emptyList())
    val recentApps: StateFlow<List<VirtualAppEntity>> = _recentApps.asStateFlow()

    private val _resourceStats = MutableStateFlow(SystemResourceStats())
    val resourceStats: StateFlow<SystemResourceStats> = _resourceStats.asStateFlow()

    private val engineScope = CoroutineScope(Dispatchers.IO + Job())
    private var statsJob: Job? = null

    init {
        startResourceMonitor()
    }

    private fun startResourceMonitor() {
        statsJob?.cancel()
        statsJob = engineScope.launch {
            while (isActive) {
                delay(1200)
                val cpuBase = (18..42).random()
                val ramBase = (1750..2200).random()
                val netDown = (45..380).random() + ((0..9).random() / 10.0)
                val netUp = (12..85).random() + ((0..9).random() / 10.0)
                _resourceStats.value = SystemResourceStats(
                    cpuLoadPercentage = cpuBase,
                    usedRamMb = ramBase,
                    totalAllocatedRamMb = 3072,
                    usedStorageMb = 4200,
                    totalAllocatedStorageMb = 16384,
                    networkDownKbps = netDown,
                    networkUpKbps = netUp,
                    batteryTemperatureC = 33.0f + (cpuBase / 10f),
                    fps = 60
                )
            }
        }
    }

    suspend fun createDefaultInstanceIfNone(): VirtualInstanceEntity {
        val existing = instanceDao.getAllInstances().firstOrNull()
        if (!existing.isNullOrEmpty()) {
            return existing.first()
        }

        val instanceId = UUID.randomUUID().toString()
        val defaultInstance = VirtualInstanceEntity(
            id = instanceId,
            name = "Android 12 — Main",
            androidVersion = "Android 12 (API 31 - Snow Cone)",
            buildId = "SQ3A.220705.004",
            status = "STOPPED",
            ramMb = 3072,
            cpuCores = 4,
            storageGb = 16,
            virtualRootEnabled = true,
            performanceMode = "BALANCED",
            resolutionWidth = 1080,
            resolutionHeight = 2340,
            dpi = 420,
            orientation = "PORTRAIT",
            virtualInternet = true,
            cameraAccess = true,
            micAccess = true,
            audioOutput = true,
            clipboardSync = true,
            isDefault = true,
            createdAt = System.currentTimeMillis()
        )

        instanceDao.insertInstance(defaultInstance)
        packageManager.initializeDefaultSystemApps(instanceId)
        fileSystem.initializeDefaultFileSystem(instanceId)

        return defaultInstance
    }

    suspend fun createNewInstance(
        name: String,
        ramMb: Int,
        cpuCores: Int,
        storageGb: Int,
        virtualRootEnabled: Boolean
    ): VirtualInstanceEntity {
        val instanceId = UUID.randomUUID().toString()
        val instance = VirtualInstanceEntity(
            id = instanceId,
            name = name,
            androidVersion = "Android 12 (API 31 - Snow Cone)",
            buildId = "SQ3A.220705.004",
            status = "STOPPED",
            ramMb = ramMb,
            cpuCores = cpuCores,
            storageGb = storageGb,
            virtualRootEnabled = virtualRootEnabled,
            performanceMode = "BALANCED",
            resolutionWidth = 1080,
            resolutionHeight = 2340,
            dpi = 420,
            orientation = "PORTRAIT",
            isDefault = false,
            createdAt = System.currentTimeMillis()
        )

        instanceDao.insertInstance(instance)
        packageManager.initializeDefaultSystemApps(instanceId)
        fileSystem.initializeDefaultFileSystem(instanceId)
        return instance
    }

    suspend fun startInstance(instanceId: String) {
        val instance = instanceDao.getInstanceById(instanceId) ?: return
        _isBooting.value = true
        _bootProgress.value = 0f
        _bootLogs.value = emptyList()

        val logs = listOf(
            "[    0.000000] Booting Linux on physical CPU 0x0000000000 [0x410fd034]",
            "[    0.000000] Linux version 5.10.136-android12-9-g3918a (rubix-builder@virt) #1 SMP PREEMPT",
            "[    0.142850] GICv3: CPU0: found redistributor 0 region 0:0x0000000800000000",
            "[    0.389201] Memory: ${instance.ramMb}MB available, kernel reserved 128MB",
            "[    0.720194] rubix-virt: Initializing Zero-ADB isolated guest sandbox...",
            "[    1.020412] init: init first stage started!",
            "[    1.340918] init: Using Android 12 Snow Cone system manifest (API 31)",
            "[    1.782019] init: Loading SELinux policy (mode: permissive, root: ${if (instance.virtualRootEnabled) "enabled" else "disabled"})...",
            "[    2.102830] servicemanager: Starting SurfaceFlinger and HAL drivers...",
            "[    2.482910] Zygote: Preloading classes and system resources...",
            "[    2.890124] SystemServer: Starting Android 12 Core Services (PackageManager, ActivityManager, WindowManager)...",
            "[    3.210492] SystemUI: Initializing Material You Monet theme and Notification shade...",
            "[    3.582910] Launcher3: Android 12 Workspace ready. System boot completed successfully."
        )

        val logAccumulator = mutableListOf<String>()
        logs.forEachIndexed { index, log ->
            delay(120)
            logAccumulator.add(log)
            _bootLogs.value = logAccumulator.toList()
            _bootProgress.value = (index + 1).toFloat() / logs.size
        }

        instanceDao.updateStatus(instanceId, "RUNNING")
        _isBooting.value = false
    }

    suspend fun stopInstance(instanceId: String) {
        _activeApp.value = null
        _recentApps.value = emptyList()
        instanceDao.updateStatus(instanceId, "STOPPED")
    }

    suspend fun pauseInstance(instanceId: String) {
        instanceDao.updateStatus(instanceId, "PAUSED")
    }

    suspend fun resumeInstance(instanceId: String) {
        instanceDao.updateStatus(instanceId, "RUNNING")
    }

    suspend fun deleteInstance(instanceId: String) {
        stopInstance(instanceId)
        appDao.deleteAppsByInstance(instanceId)
        fileDao.deleteFilesByInstance(instanceId)
        snapshotDao.deleteSnapshotsByInstance(instanceId)
        instanceDao.deleteInstance(instanceId)
    }

    suspend fun cloneInstance(sourceId: String, newName: String): VirtualInstanceEntity? {
        val source = instanceDao.getInstanceById(sourceId) ?: return null
        val newId = UUID.randomUUID().toString()
        val clone = source.copy(
            id = newId,
            name = newName,
            status = "STOPPED",
            isDefault = false,
            createdAt = System.currentTimeMillis()
        )
        instanceDao.insertInstance(clone)

        // Clone Apps
        val apps = appDao.getAppsByInstance(sourceId).firstOrNull() ?: emptyList()
        val clonedApps = apps.map { it.copy(id = UUID.randomUUID().toString(), instanceId = newId) }
        appDao.insertApps(clonedApps)

        // Clone Files
        val files = fileDao.getFilesByInstance(sourceId).firstOrNull() ?: emptyList()
        val clonedFiles = files.map { it.copy(id = UUID.randomUUID().toString(), instanceId = newId) }
        fileDao.insertFiles(clonedFiles)

        return clone
    }

    suspend fun createSnapshot(instanceId: String, name: String, description: String): VirtualSnapshotEntity {
        val apps = appDao.getAppsByInstance(instanceId).firstOrNull() ?: emptyList()
        val files = fileDao.getFilesByInstance(instanceId).firstOrNull() ?: emptyList()
        val snapshot = VirtualSnapshotEntity(
            id = UUID.randomUUID().toString(),
            instanceId = instanceId,
            name = name,
            description = description,
            sizeMb = 145.0,
            appsCount = apps.size,
            filesCount = files.size,
            createdAt = System.currentTimeMillis()
        )
        snapshotDao.insertSnapshot(snapshot)
        return snapshot
    }

    suspend fun restoreSnapshot(instanceId: String, snapshotId: String) {
        // In real virtual disk snapshot rollback, filesystem & package trees are reverted
        packageManager.initializeDefaultSystemApps(instanceId)
        fileSystem.initializeDefaultFileSystem(instanceId)
    }

    suspend fun deleteSnapshot(snapshotId: String) {
        snapshotDao.deleteSnapshot(snapshotId)
    }

    fun launchApp(app: VirtualAppEntity) {
        _activeApp.value = app
        val list = _recentApps.value.toMutableList()
        list.removeAll { it.packageName == app.packageName }
        list.add(0, app)
        _recentApps.value = list
    }

    fun closeActiveApp() {
        _activeApp.value = null
    }

    fun clearRecentApps() {
        _recentApps.value = emptyList()
        _activeApp.value = null
    }

    fun removeRecentApp(app: VirtualAppEntity) {
        val list = _recentApps.value.toMutableList()
        list.remove(app)
        _recentApps.value = list
        if (_activeApp.value?.packageName == app.packageName) {
            _activeApp.value = null
        }
    }
}
