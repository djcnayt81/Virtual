package com.example.domain

class VirtualTerminalEngine {

    private var isRoot: Boolean = false
    private var currentDir: String = "/storage/emulated/0"

    fun executeCommand(commandStr: String, virtualRootEnabled: Boolean): String {
        val trimmed = commandStr.trim()
        if (trimmed.isEmpty()) return ""

        val parts = trimmed.split("\\s+".toRegex())
        val cmd = parts[0].lowercase()
        val args = parts.drop(1)

        return when (cmd) {
            "help" -> """
                RUBIX VIRTUAL - Android 12 Guest Shell (toybox 0.8.4-android)
                Supported commands:
                  su          - Elevate to root UID 0 (requires Virtual Root)
                  exit        - Drop root or exit subshell
                  uname -a    - Print system and kernel info
                  id          - Print user and group IDs
                  getprop     - Get Android system properties
                  setprop     - Set guest system property
                  ps          - List active guest processes
                  top         - Real-time guest process snapshot
                  df -h       - Display virtual disk filesystem usage
                  free -m     - Display virtual RAM statistics
                  pm          - Package manager (list packages, install)
                  ping        - Test virtual network connectivity
                  ls          - List directory contents
                  cd          - Change directory
                  pwd         - Print working directory
                  cat         - Concatenate and display file content
                  echo        - Print text
                  mkdir       - Create directory
                  rm          - Remove file
                  clear       - Clear terminal buffer
            """.trimIndent()

            "su" -> {
                if (!virtualRootEnabled) {
                    "su: Permission denied (Virtual Root is disabled in RUBIX settings)"
                } else {
                    isRoot = true
                    "Elevated to root. UID=0(root) GID=0(root) SELinux=permissive"
                }
            }

            "exit" -> {
                if (isRoot) {
                    isRoot = false
                    "Dropped root privileges. Back to shell (uid 1000)."
                } else {
                    "Logged out of interactive subshell."
                }
            }

            "uname" -> {
                if (args.contains("-a") || args.isEmpty()) {
                    "Linux rubix-a12-vbox 5.10.136-android12-9-g3918a #1 SMP PREEMPT PREEMPT_DYNAMIC aarch64 Android"
                } else {
                    "Linux"
                }
            }

            "id" -> {
                if (isRoot) {
                    "uid=0(root) gid=0(root) groups=0(root),1004(input),1007(log),1011(adb),1015(sdcard_rw),1028(sdcard_r),3003(inet) context=u:r:su:s0"
                } else {
                    "uid=2000(shell) gid=2000(shell) groups=2000(shell),1004(input),1007(log),1015(sdcard_rw),3003(inet) context=u:r:shell:s0"
                }
            }

            "getprop" -> {
                if (args.isNotEmpty()) {
                    val prop = args[0]
                    when (prop) {
                        "ro.build.version.release" -> "12"
                        "ro.build.version.sdk" -> "31"
                        "ro.product.model" -> "RUBIX-V12"
                        "ro.product.brand" -> "Rubix"
                        "ro.product.manufacturer" -> "RubixVirtual"
                        "ro.build.id" -> "SQ3A.220705.004"
                        "ro.rubix.root" -> if (virtualRootEnabled) "enabled" else "disabled"
                        "ro.rubix.debug.wifi" -> "none (zero dependency)"
                        else -> "[unknown property: $prop]"
                    }
                } else {
                    """
                    [ro.build.id]: [SQ3A.220705.004]
                    [ro.build.version.release]: [12]
                    [ro.build.version.sdk]: [31]
                    [ro.build.version.codename]: [REL]
                    [ro.product.brand]: [Rubix]
                    [ro.product.model]: [RUBIX-V12-GUEST]
                    [ro.product.manufacturer]: [Rubix Technologies]
                    [ro.product.cpu.abi]: [arm64-v8a]
                    [ro.product.cpu.abilist]: [arm64-v8a,armeabi-v7a,armeabi]
                    [ro.rubix.virtualization]: [KVM/User-Sandbox Native-Engine]
                    [ro.rubix.root]: [${if (virtualRootEnabled) "enabled" else "disabled"}]
                    [ro.rubix.wifi_debugging]: [not_required]
                    [sys.boot_completed]: [1]
                    """.trimIndent()
                }
            }

            "setprop" -> {
                if (!isRoot && !virtualRootEnabled) {
                    "setprop: Permission denied (must run as root/su)"
                } else if (args.size < 2) {
                    "usage: setprop <key> <value>"
                } else {
                    "[setprop] Property ${args[0]} updated to '${args.subList(1, args.size).joinToString(" ")}'"
                }
            }

            "ps" -> """
                USER           PID  PPID     VSZ    RSS WCHAN            ADDR S NAME
                root             1     0   10244   1280 0                   0 S init
                root           245     1   23480   4512 0                   0 S /system/bin/servicemanager
                system         312     1   54280   8920 0                   0 S /system/bin/surfaceflinger
                root           380     1  128400  32100 0                   0 S main (zygote64)
                system         560   380 2450120 184500 0                   0 S system_server
                u0_a12         840   380 1820400 112000 0                   0 S com.android.systemui
                u0_a15        1120   380 1710200  95000 0                   0 S com.android.launcher3
                ${if (isRoot) "root" else "shell"}          1890   560   14200   2400 0                   0 R ${if (isRoot) "su" else "sh"}
            """.trimIndent()

            "top" -> """
                Tasks: 84 total, 1 running, 83 sleeping, 0 stopped, 0 zombie
                %Cpu(s): 14.2 us,  3.8 sy,  0.0 ni, 81.6 id,  0.4 wa,  0.0 hi,  0.0 si
                MiB Mem :   3072.0 total,   1232.0 free,   1840.0 used,    340.0 buff/cache
                MiB Swap:   2048.0 total,   2048.0 free,      0.0 used.   1120.0 avail Mem

                  PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
                  560 system    20   0 2450120 184500  48200 S   6.2   5.8   0:45.12 system_server
                  312 system   -16   0   54280   8920   3400 S   4.5   0.3   0:28.40 surfaceflinger
                  840 u0_a12    20   0 1820400 112000  38000 S   2.1   3.5   0:14.20 systemui
                 1120 u0_a15    20   0 1710200  95000  32000 S   0.8   3.0   0:06.85 launcher3
            """.trimIndent()

            "df" -> """
                Filesystem                      Size  Used Avail Use% Mounted on
                /dev/block/dm-0                 4.2G  3.1G  1.1G  74% /
                /dev/block/dm-1                 1.8G  1.4G  400M  78% /system
                /dev/block/dm-2                 850M  620M  230M  73% /vendor
                /dev/block/dm-3                 450M  310M  140M  69% /product
                /dev/block/by-name/userdata      16G  4.2G   11G  27% /data
                /data/media                      16G  4.2G   11G  27% /storage/emulated/0
            """.trimIndent()

            "free" -> """
                           total        used        free      shared     buffers
                Mem:     3145728     1884160     1261568       32768       94208
                Swap:    2097152           0     2097152
            """.trimIndent()

            "pm" -> {
                if (args.contains("list") && args.contains("packages")) {
                    """
                    package:com.android.settings
                    package:com.android.documentsui
                    package:com.android.browser
                    package:com.android.camera2
                    package:com.android.gallery3d
                    package:com.rubix.terminal
                    package:com.android.music
                    package:com.android.calculator2
                    package:com.android.notes
                    package:com.android.deskclock
                    package:com.android.packageinstaller
                    package:com.android.systemui
                    package:com.android.launcher3
                    """.trimIndent()
                } else {
                    "usage: pm list packages | pm path <package> | pm clear <package>"
                }
            }

            "ping" -> {
                val host = if (args.isNotEmpty()) args[0] else "8.8.8.8"
                """
                PING $host ($host) 56(84) bytes of data.
                64 bytes from $host: icmp_seq=1 ttl=118 time=14.2 ms
                64 bytes from $host: icmp_seq=2 ttl=118 time=13.8 ms
                64 bytes from $host: icmp_seq=3 ttl=118 time=15.1 ms
                --- $host ping statistics ---
                3 packets transmitted, 3 received, 0% packet loss, time 2003ms
                rtt min/avg/max/mdev = 13.8/14.36/15.1/0.54 ms
                """.trimIndent()
            }

            "pwd" -> currentDir

            "cd" -> {
                if (args.isEmpty() || args[0] == "~") {
                    currentDir = "/storage/emulated/0"
                    ""
                } else {
                    val target = args[0]
                    currentDir = if (target.startsWith("/")) target else "$currentDir/$target"
                    ""
                }
            }

            "ls" -> """
                Android/
                DCIM/
                Download/
                Music/
                Movies/
                Pictures/
                Documents/
                Welcome_Android12.txt
            """.trimIndent()

            "echo" -> args.joinToString(" ")

            "clear" -> "__CLEAR__"

            else -> "$cmd: command not found (type 'help' for available commands)"
        }
    }

    fun getPrompt(virtualRootEnabled: Boolean): String {
        return if (isRoot && virtualRootEnabled) {
            "root@rubix-a12:${currentDir}# "
        } else {
            "shell@rubix-a12:${currentDir}$ "
        }
    }

    fun isRootActive(): Boolean = isRoot
}
