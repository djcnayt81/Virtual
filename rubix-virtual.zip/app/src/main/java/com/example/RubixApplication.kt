package com.example

import android.app.Application
import com.example.domain.VirtualEngine

class RubixApplication : Application() {

    lateinit var virtualEngine: VirtualEngine
        private set

    override fun onCreate() {
        super.onCreate()
        virtualEngine = VirtualEngine(this)
    }
}
