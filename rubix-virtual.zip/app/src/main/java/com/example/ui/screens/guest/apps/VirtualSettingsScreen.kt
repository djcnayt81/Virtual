package com.example.ui.screens.guest.apps

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.VirtualAppEntity
import com.example.data.local.entity.VirtualInstanceEntity
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.MonetGreen
import com.example.ui.theme.MonetPeach
import com.example.ui.theme.MonetSky
import com.example.ui.theme.RubixAmber
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixMint
import com.example.ui.theme.RubixRed

enum class SettingsSection {
    MAIN,
    NETWORK,
    DISPLAY,
    STORAGE,
    APPS,
    APP_DETAIL,
    SECURITY_ROOT,
    ABOUT_DEVICE
}

@Composable
fun VirtualSettingsScreen(
    instance: VirtualInstanceEntity,
    apps: List<VirtualAppEntity>,
    onToggleRoot: () -> Unit,
    onSetWallpaper: (Int) -> Unit,
    onForceStopApp: (VirtualAppEntity) -> Unit,
    onClearAppCache: (VirtualAppEntity) -> Unit,
    onClearAppData: (VirtualAppEntity) -> Unit,
    onUninstallApp: (VirtualAppEntity) -> Unit,
    onToggleAppRoot: (VirtualAppEntity) -> Unit,
    onCloseApp: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentSection by remember { mutableStateOf(SettingsSection.MAIN) }
    var selectedAppForDetail by remember { mutableStateOf<VirtualAppEntity?>(null) }

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // App Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceCard)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentSection != SettingsSection.MAIN) {
                    IconButton(
                        onClick = {
                            if (currentSection == SettingsSection.APP_DETAIL) {
                                currentSection = SettingsSection.APPS
                            } else {
                                currentSection = SettingsSection.MAIN
                            }
                        }
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                } else {
                    IconButton(onClick = onCloseApp) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Exit Settings", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = when (currentSection) {
                        SettingsSection.MAIN -> "Settings"
                        SettingsSection.NETWORK -> "Network & Internet"
                        SettingsSection.DISPLAY -> "Display & Theme"
                        SettingsSection.STORAGE -> "Virtual Storage"
                        SettingsSection.APPS -> "Apps (${apps.size})"
                        SettingsSection.APP_DETAIL -> selectedAppForDetail?.appName ?: "App Info"
                        SettingsSection.SECURITY_ROOT -> "Security & Virtual Root"
                        SettingsSection.ABOUT_DEVICE -> "About Virtual Device"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            Divider(color = DarkSurfaceBorder)

            // Content per section
            when (currentSection) {
                SettingsSection.MAIN -> SettingsMainList(
                    instance = instance,
                    onNavigate = { currentSection = it }
                )
                SettingsSection.NETWORK -> NetworkSettings(instance = instance)
                SettingsSection.DISPLAY -> DisplaySettings(
                    instance = instance,
                    onSetWallpaper = onSetWallpaper
                )
                SettingsSection.STORAGE -> StorageSettings(instance = instance)
                SettingsSection.APPS -> AppsListSettings(
                    apps = apps,
                    onSelectApp = {
                        selectedAppForDetail = it
                        currentSection = SettingsSection.APP_DETAIL
                    }
                )
                SettingsSection.APP_DETAIL -> {
                    selectedAppForDetail?.let { app ->
                        AppDetailSettings(
                            app = app,
                            onForceStop = { onForceStopApp(app) },
                            onClearCache = { onClearAppCache(app) },
                            onClearData = { onClearAppData(app) },
                            onUninstall = {
                                onUninstallApp(app)
                                currentSection = SettingsSection.APPS
                            },
                            onToggleRoot = { onToggleAppRoot(app) }
                        )
                    }
                }
                SettingsSection.SECURITY_ROOT -> SecurityRootSettings(
                    instance = instance,
                    apps = apps,
                    onToggleRoot = onToggleRoot,
                    onToggleAppRoot = onToggleAppRoot
                )
                SettingsSection.ABOUT_DEVICE -> AboutDeviceSettings(instance = instance)
            }
        }
    }
}

@Composable
private fun SettingsMainList(
    instance: VirtualInstanceEntity,
    onNavigate: (SettingsSection) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Wifi,
                iconColor = MonetSky,
                title = "Network & internet",
                subtitle = "Virtual Wi-Fi bridge, Zero-ADB sandbox, DNS",
                onClick = { onNavigate(SettingsSection.NETWORK) }
            )
        }
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Tv,
                iconColor = MonetPeach,
                title = "Display",
                subtitle = "${instance.resolutionWidth}x${instance.resolutionHeight}, ${instance.dpi} DPI, Wallpaper",
                onClick = { onNavigate(SettingsSection.DISPLAY) }
            )
        }
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Storage,
                iconColor = MonetGreen,
                title = "Storage",
                subtitle = "4.2 GB used of ${instance.storageGb} GB total",
                onClick = { onNavigate(SettingsSection.STORAGE) }
            )
        }
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Apps,
                iconColor = RubixCyan,
                title = "Apps & permissions",
                subtitle = "Installed applications, force stop, storage quotas",
                onClick = { onNavigate(SettingsSection.APPS) }
            )
        }
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Security,
                iconColor = if (instance.virtualRootEnabled) RubixMint else Color.Gray,
                title = "Security & Virtual Root",
                subtitle = if (instance.virtualRootEnabled) "Virtual Root: ENABLED (Guest UID 0)" else "Virtual Root: DISABLED",
                onClick = { onNavigate(SettingsSection.SECURITY_ROOT) }
            )
        }
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Smartphone,
                iconColor = RubixAmber,
                title = "About virtual device",
                subtitle = "RUBIX-V12, Android 12 Snow Cone (API 31)",
                onClick = { onNavigate(SettingsSection.ABOUT_DEVICE) }
            )
        }
    }
}

@Composable
private fun SettingsCategoryCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(iconColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(22.dp))
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(text = title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
        }
    }
}

@Composable
private fun NetworkSettings(instance: VirtualInstanceEntity) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "VIRTUAL NETWORK ADAPTER", style = MaterialTheme.typography.labelSmall, color = RubixCyan)
                Spacer(modifier = Modifier.height(10.dp))
                InfoItem("Status", "Connected (Virtual Bridge)")
                InfoItem("SSID", "Rubix-Virtual-A12")
                InfoItem("IP Address", "10.0.2.15")
                InfoItem("Gateway", "10.0.2.2")
                InfoItem("DNS Server", "8.8.8.8, 1.1.1.1")
                InfoItem("MAC Address", "02:00:00:12:34:56 (Virtual)")
                InfoItem("Wi-Fi Debugging", "Disabled / Not Required")
            }
        }
    }
}

@Composable
private fun DisplaySettings(
    instance: VirtualInstanceEntity,
    onSetWallpaper: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "DISPLAY SPECIFICATIONS", style = MaterialTheme.typography.labelSmall, color = RubixCyan)
                Spacer(modifier = Modifier.height(10.dp))
                InfoItem("Virtual Resolution", "${instance.resolutionWidth} x ${instance.resolutionHeight} (FHD+)")
                InfoItem("Screen Density", "${instance.dpi} DPI (xhdpi)")
                InfoItem("Refresh Rate", "60 Hz HW-Synced")
                InfoItem("Dynamic Theming", "Monet Android 12 Engine")
            }
        }

        Text(text = "SELECT WALLPAPER", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val names = listOf("Aurora", "Emerald", "Titanium", "Sunset")
            val colors = listOf(Color(0xFF2C5364), Color(0xFF00523F), Color(0xFF1E293B), Color(0xFF7597DE))
            names.forEachIndexed { index, name ->
                val isSel = instance.wallpaperIndex == index
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = colors[index],
                    border = BorderStroke(2.dp, if (isSel) RubixCyan else Color.Transparent),
                    modifier = Modifier
                        .weight(1f)
                        .height(80.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSetWallpaper(index) }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isSel) Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                        else Text(text = name, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun StorageSettings(instance: VirtualInstanceEntity) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "VIRTUAL STORAGE ALLOCATION", style = MaterialTheme.typography.labelSmall, color = RubixCyan)
                Spacer(modifier = Modifier.height(10.dp))
                Text(text = "4.2 GB used of ${instance.storageGb} GB", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                Spacer(modifier = Modifier.height(8.dp))

                // Progress Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(DarkSurfaceElevated)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(4.2f / instance.storageGb)
                            .height(10.dp)
                            .background(RubixCyan)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                InfoItem("System OS (Android 12)", "3.1 GB")
                InfoItem("Apps & Packages", "840 MB")
                InfoItem("Virtual /storage/emulated/0", "260 MB")
                InfoItem("Free Space", "${instance.storageGb - 4.2} GB")
            }
        }
    }
}

@Composable
private fun AppsListSettings(
    apps: List<VirtualAppEntity>,
    onSelectApp: (VirtualAppEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(apps) { app ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelectApp(app) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = app.appName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        Text(text = "${app.packageName} • ${app.versionName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(text = "${app.dataSizeMb} MB", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = RubixCyan)
                }
            }
        }
    }
}

@Composable
private fun AppDetailSettings(
    app: VirtualAppEntity,
    onForceStop: () -> Unit,
    onClearCache: () -> Unit,
    onClearData: () -> Unit,
    onUninstall: () -> Unit,
    onToggleRoot: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = app.appName, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = Color.White)
                Text(text = "Package: ${app.packageName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = "Version: ${app.versionName} (Build ${app.versionCode})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = "Type: ${if (app.isSystemApp) "System Framework Package" else "User Installed APK"}", style = MaterialTheme.typography.bodySmall, color = RubixCyan)
            }
        }

        // Action Buttons: FORCE STOP | UNINSTALL
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onForceStop,
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated, contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("FORCE STOP")
            }

            if (!app.isSystemApp) {
                Button(
                    onClick = onUninstall,
                    colors = ButtonDefaults.buttonColors(containerColor = RubixRed.copy(alpha = 0.2f), contentColor = RubixRed),
                    border = BorderStroke(1.dp, RubixRed.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("UNINSTALL")
                }
            }
        }

        // Storage & Cache
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "STORAGE & CACHE", style = MaterialTheme.typography.labelSmall, color = RubixCyan)
                Spacer(modifier = Modifier.height(8.dp))
                InfoItem("App Size", "${app.dataSizeMb} MB")
                InfoItem("Cache Size", "${app.cacheSizeMb} MB")
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onClearCache,
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("CLEAR CACHE", fontSize = 11.sp)
                    }
                    Button(
                        onClick = onClearData,
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("CLEAR DATA", fontSize = 11.sp)
                    }
                }
            }
        }

        // Permissions
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "DECLARED PERMISSIONS", style = MaterialTheme.typography.labelSmall, color = RubixCyan)
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = app.grantedPermissions.split(",").joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = Color.White)
            }
        }
    }
}

@Composable
private fun SecurityRootSettings(
    instance: VirtualInstanceEntity,
    apps: List<VirtualAppEntity>,
    onToggleRoot: () -> Unit,
    onToggleAppRoot: (VirtualAppEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "RUBIX VIRTUAL ROOT", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                            Text(
                                text = if (instance.virtualRootEnabled) "ENABLED (Guest UID 0 Active)" else "DISABLED",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (instance.virtualRootEnabled) RubixMint else Color.Gray
                            )
                        }
                        Switch(
                            checked = instance.virtualRootEnabled,
                            onCheckedChange = { onToggleRoot() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = RubixMint
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Virtual Root applies ONLY inside the Android 12 guest container. The host device remains strictly untouched and non-rooted.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Text(text = "GUEST SUPERUSER APP ACCESS", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
        }

        items(apps) { app ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = app.appName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        Text(text = app.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = app.rootAccessGranted && instance.virtualRootEnabled,
                        onCheckedChange = { onToggleAppRoot(app) },
                        enabled = instance.virtualRootEnabled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = RubixMint
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun AboutDeviceSettings(instance: VirtualInstanceEntity) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "VIRTUAL DEVICE INFORMATION", style = MaterialTheme.typography.labelSmall, color = RubixCyan)
                Spacer(modifier = Modifier.height(10.dp))
                InfoItem("Device Model", "RUBIX-V12 (VMOS-Style Container)")
                InfoItem("Android Version", "Android 12 (API 31 - Snow Cone)")
                InfoItem("Build ID", instance.buildId)
                InfoItem("Virtual Kernel", "Linux 5.10.136-android12-9-g3918a")
                InfoItem("Architecture", "aarch64 / arm64-v8a Native")
                InfoItem("Host Isolation", "Strict Sandboxed Userland Container")
                InfoItem("Wi-Fi Debugging", "Zero Dependency (Not Required)")
                InfoItem("Security Patch Level", "July 5, 2026")
            }
        }
    }
}

@Composable
private fun InfoItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace), color = Color.White)
    }
}
