package com.example.ui.screens.guest

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SignalCellular4Bar
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.VirtualAppEntity
import com.example.data.local.entity.VirtualFileEntity
import com.example.data.local.entity.VirtualInstanceEntity
import com.example.ui.screens.guest.apps.VirtualBrowserScreen
import com.example.ui.screens.guest.apps.VirtualCalculatorScreen
import com.example.ui.screens.guest.apps.VirtualCameraScreen
import com.example.ui.screens.guest.apps.VirtualClockScreen
import com.example.ui.screens.guest.apps.VirtualFileManagerScreen
import com.example.ui.screens.guest.apps.VirtualGalleryScreen
import com.example.ui.screens.guest.apps.VirtualGenericAppScreen
import com.example.ui.screens.guest.apps.VirtualMusicScreen
import com.example.ui.screens.guest.apps.VirtualNotesScreen
import com.example.ui.screens.guest.apps.VirtualPackageInstallerScreen
import com.example.ui.screens.guest.apps.VirtualSettingsScreen
import com.example.ui.screens.guest.apps.VirtualTerminalScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.RubixAmber
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixMint
import com.example.ui.theme.RubixRed
import com.example.viewmodel.GuestDisplayMode
import com.example.viewmodel.TerminalLine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VirtualAndroidScreen(
    instance: VirtualInstanceEntity?,
    apps: List<VirtualAppEntity>,
    files: List<VirtualFileEntity>,
    bootLogs: List<String>,
    bootProgress: Float,
    isBooting: Boolean,
    activeApp: VirtualAppEntity?,
    recentApps: List<VirtualAppEntity>,
    displayMode: GuestDisplayMode,
    isQuickSettingsOpen: Boolean,
    isRecentAppsOpen: Boolean,
    isAppDrawerOpen: Boolean,
    terminalLines: List<TerminalLine>,
    onStartInstance: () -> Unit,
    onStopInstance: () -> Unit,
    onToggleRoot: () -> Unit,
    onSetWallpaper: (Int) -> Unit,
    onLaunchApp: (VirtualAppEntity) -> Unit,
    onCloseActiveApp: () -> Unit,
    onToggleRecentApps: () -> Unit,
    onCloseRecentApps: () -> Unit,
    onClearAllRecentApps: () -> Unit,
    onRemoveRecentApp: (VirtualAppEntity) -> Unit,
    onToggleAppDrawer: () -> Unit,
    onCloseAppDrawer: () -> Unit,
    onToggleQuickSettings: () -> Unit,
    onCloseQuickSettings: () -> Unit,
    onSetDisplayMode: (GuestDisplayMode) -> Unit,
    // App actions
    onForceStopApp: (VirtualAppEntity) -> Unit,
    onClearAppCache: (VirtualAppEntity) -> Unit,
    onClearAppData: (VirtualAppEntity) -> Unit,
    onUninstallApp: (VirtualAppEntity) -> Unit,
    onToggleAppRoot: (VirtualAppEntity) -> Unit,
    onInstallSampleApk: (String, String, String, String, Double) -> Unit,
    onInstallCustomApk: (String, String, Double) -> Unit,
    onCreateFolder: (String, String) -> Unit,
    onCreateTextFile: (String, String, String) -> Unit,
    onDeleteFile: (VirtualFileEntity) -> Unit,
    onExecuteTerminalCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (instance == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No virtual instance selected.", color = Color.White)
        }
        return
    }

    // If STOPPED or BOOTING
    if (instance.status != "RUNNING" || isBooting) {
        BootingScreen(
            instance = instance,
            bootLogs = bootLogs,
            bootProgress = bootProgress,
            isBooting = isBooting,
            onStartInstance = onStartInstance,
            modifier = modifier
        )
        return
    }

    // RUNNING Guest OS Container
    val timeFormat = SimpleDateFormat("h:mm", Locale.getDefault())
    val now = Date()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Android 12 Guest Status Bar
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleQuickSettings() }
                    .testTag("guest_status_bar")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Time & Root icon
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = timeFormat.format(now),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            ),
                            color = Color.White
                        )
                        if (instance.virtualRootEnabled) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Virtual Root Active",
                                tint = RubixMint,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }

                    // Network & Battery Status Icons
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Wifi, contentDescription = "Virtual Net", tint = Color.White, modifier = Modifier.size(13.dp))
                        Icon(Icons.Default.SignalCellular4Bar, contentDescription = "Cellular", tint = Color.White, modifier = Modifier.size(13.dp))
                        Icon(Icons.Default.BatteryFull, contentDescription = "Battery", tint = Color.White, modifier = Modifier.size(14.dp))
                        Text(
                            text = "100%",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = Color.White
                        )
                    }
                }
            }

            // 2. Active Screen Viewport (Home Screen or Active App)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (activeApp == null) {
                    Android12HomeScreen(
                        apps = apps,
                        wallpaperIndex = instance.wallpaperIndex,
                        isAppDrawerOpen = isAppDrawerOpen,
                        onLaunchApp = onLaunchApp,
                        onToggleAppDrawer = onToggleAppDrawer,
                        onCloseAppDrawer = onCloseAppDrawer
                    )
                } else {
                    // Render the active app
                    when (activeApp.packageName) {
                        "com.android.settings" -> VirtualSettingsScreen(
                            instance = instance,
                            apps = apps,
                            onToggleRoot = onToggleRoot,
                            onSetWallpaper = onSetWallpaper,
                            onForceStopApp = onForceStopApp,
                            onClearAppCache = onClearAppCache,
                            onClearAppData = onClearAppData,
                            onUninstallApp = onUninstallApp,
                            onToggleAppRoot = onToggleAppRoot,
                            onCloseApp = onCloseActiveApp
                        )
                        "com.android.documentsui" -> VirtualFileManagerScreen(
                            files = files,
                            onCreateFolder = onCreateFolder,
                            onCreateTextFile = onCreateTextFile,
                            onDeleteFile = onDeleteFile,
                            onCloseApp = onCloseActiveApp
                        )
                        "com.rubix.terminal" -> VirtualTerminalScreen(
                            instance = instance,
                            terminalLines = terminalLines,
                            onExecuteCommand = onExecuteTerminalCommand,
                            onCloseApp = onCloseActiveApp
                        )
                        "com.android.packageinstaller" -> VirtualPackageInstallerScreen(
                            installedApps = apps,
                            onInstallSampleApk = onInstallSampleApk,
                            onInstallCustomApk = onInstallCustomApk,
                            onCloseApp = onCloseActiveApp
                        )
                        "com.android.browser" -> VirtualBrowserScreen(onCloseApp = onCloseActiveApp)
                        "com.android.camera2" -> VirtualCameraScreen(onCloseApp = onCloseActiveApp)
                        "com.android.gallery3d" -> VirtualGalleryScreen(onCloseApp = onCloseActiveApp)
                        "com.android.music" -> VirtualMusicScreen(onCloseApp = onCloseActiveApp)
                        "com.android.calculator2" -> VirtualCalculatorScreen(onCloseApp = onCloseActiveApp)
                        "com.android.notes" -> VirtualNotesScreen(onCloseApp = onCloseActiveApp)
                        "com.android.deskclock" -> VirtualClockScreen(onCloseApp = onCloseActiveApp)
                        else -> VirtualGenericAppScreen(app = activeApp, onCloseApp = onCloseActiveApp)
                    }
                }

                // Quick Settings Dropdown Overlay
                androidx.compose.animation.AnimatedVisibility(
                    visible = isQuickSettingsOpen,
                    enter = slideInVertically(initialOffsetY = { -it }),
                    exit = slideOutVertically(targetOffsetY = { -it })
                ) {
                    QuickSettingsPanel(
                        instance = instance,
                        onToggleRoot = onToggleRoot,
                        onOpenSettings = {
                            val settingsApp = apps.find { it.packageName == "com.android.settings" }
                            if (settingsApp != null) onLaunchApp(settingsApp)
                        },
                        onClose = onCloseQuickSettings
                    )
                }

                // Recent Apps Overlay
                androidx.compose.animation.AnimatedVisibility(
                    visible = isRecentAppsOpen,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    RecentAppsOverlay(
                        recentApps = recentApps,
                        onSelectApp = { app ->
                            onLaunchApp(app)
                            onCloseRecentApps()
                        },
                        onRemoveApp = onRemoveRecentApp,
                        onClearAll = onClearAllRecentApps,
                        onClose = onCloseRecentApps
                    )
                }
            }

            // 3. Android 12 Bottom Navigation Bar (Back, Home, Recents)
            Surface(
                color = Color.Black,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("guest_nav_bar")
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back button
                    IconButton(
                        onClick = {
                            if (isQuickSettingsOpen) onCloseQuickSettings()
                            else if (isRecentAppsOpen) onCloseRecentApps()
                            else if (isAppDrawerOpen) onCloseAppDrawer()
                            else if (activeApp != null) onCloseActiveApp()
                        },
                        modifier = Modifier.testTag("guest_nav_back")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    // Home button
                    IconButton(
                        onClick = {
                            onCloseQuickSettings()
                            onCloseRecentApps()
                            onCloseAppDrawer()
                            onCloseActiveApp()
                        },
                        modifier = Modifier.testTag("guest_nav_home")
                    ) {
                        Icon(Icons.Default.Home, contentDescription = "Home", tint = Color.White, modifier = Modifier.size(22.dp))
                    }

                    // Recents button
                    IconButton(
                        onClick = onToggleRecentApps,
                        modifier = Modifier.testTag("guest_nav_recents")
                    ) {
                        Icon(Icons.Default.CropSquare, contentDescription = "Recents", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun BootingScreen(
    instance: VirtualInstanceEntity,
    bootLogs: List<String>,
    bootProgress: Float,
    isBooting: Boolean,
    onStartInstance: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(bootLogs.size) {
        if (bootLogs.isNotEmpty()) {
            listState.animateScrollToItem(bootLogs.lastIndex)
        }
    }

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 20.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(RubixCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = RubixCyan,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = instance.name,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                    color = Color.White
                )
                Text(
                    text = if (isBooting) "BOOTING ANDROID 12 KERNEL & SYSTEM..." else "VIRTUAL ENVIRONMENT STOPPED",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (isBooting) RubixMint else RubixAmber
                )
            }

            // Boot Progress & dmesg logs
            if (isBooting || bootLogs.isNotEmpty()) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF070B12)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "GUEST DMESG LOGS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = RubixCyan
                            )
                            Text(
                                text = "${(bootProgress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = RubixMint
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { bootProgress },
                            color = RubixCyan,
                            trackColor = DarkSurfaceElevated,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(bootLogs) { log ->
                                Text(
                                    text = log,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        lineHeight = 14.sp
                                    ),
                                    color = if (log.contains("ready") || log.contains("completed")) RubixMint else Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            } else {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Ready to Launch Android 12",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "RAM: ${instance.ramMb / 1024} GB • CPU: ${instance.cpuCores} Cores • Root: ${if (instance.virtualRootEnabled) "Enabled" else "Disabled"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Start Button
            if (!isBooting) {
                Button(
                    onClick = onStartInstance,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RubixCyan,
                        contentColor = Color(0xFF00363D)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("boot_start_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "START ANDROID 12 ENVIRONMENT",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
