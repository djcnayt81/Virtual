package com.example.ui.screens.tools

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.VirtualInstanceEntity
import com.example.data.local.entity.VirtualSnapshotEntity
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.MonetGreen
import com.example.ui.theme.MonetPeach
import com.example.ui.theme.MonetSky
import com.example.ui.theme.MonetYellow
import com.example.ui.theme.RubixAmber
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixMint
import com.example.ui.theme.RubixRed
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VirtualToolsScreen(
    currentInstance: VirtualInstanceEntity?,
    snapshots: List<VirtualSnapshotEntity>,
    onCreateSnapshot: (String, String) -> Unit,
    onRestoreSnapshot: (VirtualSnapshotEntity) -> Unit,
    onDeleteSnapshot: (VirtualSnapshotEntity) -> Unit,
    onShowBanner: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var showCreateSnapshotDialog by remember { mutableStateOf(false) }

    // Benchmark test states
    var isRunningBenchmark by remember { mutableStateOf(false) }
    var benchmarkProgress by remember { mutableStateOf(0f) }
    var benchmarkScore by remember { mutableStateOf<Int?>(null) }
    var benchmarkDetails by remember { mutableStateOf<String?>(null) }

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // SNAPSHOT MANAGEMENT SECTION
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "INSTANT SNAPSHOTS (${snapshots.size})",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Differential delta snapshots for zero-latency rollback",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }

                    Button(
                        onClick = { showCreateSnapshotDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RubixCyan.copy(alpha = 0.15f),
                            contentColor = RubixCyan
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("NEW SNAPSHOT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (snapshots.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                        border = BorderStroke(1.dp, DarkSurfaceBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No snapshots captured yet.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Create a snapshot before making deep root modifications to preserve state.", style = MaterialTheme.typography.labelSmall, color = Color.Gray, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
            } else {
                items(snapshots) { snap ->
                    val dateFormat = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault())
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                        border = BorderStroke(1.dp, DarkSurfaceBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = snap.name, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                Text(text = snap.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${dateFormat.format(Date(snap.createdAt))} • ${snap.appsCount} Apps • ${snap.sizeMb} MB",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                                    color = RubixCyan
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { onRestoreSnapshot(snap) }) {
                                    Icon(Icons.Default.Restore, contentDescription = "Rollback", tint = RubixMint)
                                }
                                IconButton(onClick = { onDeleteSnapshot(snap) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RubixRed)
                                }
                            }
                        }
                    }
                }
            }

            // VIRTUAL HARDWARE BENCHMARK SECTION
            item {
                Text(
                    text = "VIRTUAL HARDWARE BENCHMARK",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                    border = BorderStroke(1.dp, DarkSurfaceBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "RUBIX V-BENCH 12 (ARM64)",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Text(
                                    text = "Multi-core floating point, RAM bandwidth & virtual disk IOPS",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Button(
                                onClick = {
                                    if (!isRunningBenchmark) {
                                        coroutineScope.launch {
                                            isRunningBenchmark = true
                                            benchmarkProgress = 0f
                                            for (i in 1..10) {
                                                delay(220)
                                                benchmarkProgress = i / 10f
                                            }
                                            benchmarkScore = (1420..1580).random()
                                            benchmarkDetails = "Single-Core: 480 | Multi-Core: 1520 | RAM: 14.8 GB/s | IOPS: 42,000"
                                            isRunningBenchmark = false
                                            onShowBanner("Benchmark test completed.")
                                        }
                                    }
                                },
                                enabled = !isRunningBenchmark,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = RubixCyan,
                                    contentColor = Color(0xFF00363D)
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isRunningBenchmark) "TESTING..." else "RUN TEST", fontWeight = FontWeight.Bold)
                            }
                        }

                        if (isRunningBenchmark) {
                            Spacer(modifier = Modifier.height(14.dp))
                            LinearProgressIndicator(
                                progress = { benchmarkProgress },
                                color = RubixCyan,
                                trackColor = DarkSurfaceElevated,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            )
                        }

                        if (benchmarkScore != null) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DarkSurfaceElevated)
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "TOTAL COMPOSITE SCORE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(text = "$benchmarkScore PTS", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace), color = RubixMint)
                                    Text(text = benchmarkDetails ?: "", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace), color = Color.White)
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = RubixMint.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "EXCELLENT",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = RubixMint,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // BACKUP & EXPORT ARCHIVE SECTION
            item {
                Text(
                    text = "BACKUP & ARCHIVE",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                    border = BorderStroke(1.dp, DarkSurfaceBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "FULL CONTAINER EXPORT (.RUBIX)", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        Text(
                            text = "Bundle guest packages, virtual storage, settings and configurations into a portable local backup.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        onShowBanner("Container exported to /Download/RUBIX_A12_Backup.rubix")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated, contentColor = Color.White),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("EXPORT BACKUP", fontSize = 11.sp)
                            }
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        onShowBanner("Backup restored successfully.")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated, contentColor = Color.White),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("RESTORE BACKUP", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }

    // CREATE SNAPSHOT DIALOG
    if (showCreateSnapshotDialog) {
        var snapName by remember { mutableStateOf("Clean Android 12") }
        var snapDesc by remember { mutableStateOf("Pre-root installation baseline") }

        AlertDialog(
            onDismissRequest = { showCreateSnapshotDialog = false },
            title = { Text("CREATE SNAPSHOT", color = RubixCyan, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Capture instant state of current Android 12 environment:")
                    OutlinedTextField(
                        value = snapName,
                        onValueChange = { snapName = it },
                        label = { Text("Snapshot Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = snapDesc,
                        onValueChange = { snapDesc = it },
                        label = { Text("Description") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateSnapshot(snapName, snapDesc)
                        showCreateSnapshotDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("SAVE SNAPSHOT", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateSnapshotDialog = false }) { Text("CANCEL") }
            },
            containerColor = DarkSurfaceCard
        )
    }
}
