package com.example.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.RubixCyan
import com.example.viewmodel.MainTab

@Composable
fun RubixBottomNav(
    selectedTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        // HOME
        NavigationBarItem(
            selected = selectedTab == MainTab.HOME,
            onClick = { onTabSelected(MainTab.HOME) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == MainTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = {
                Text(
                    text = "HOME",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (selectedTab == MainTab.HOME) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp
                    )
                )
            },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = RubixCyan.copy(alpha = 0.2f),
                selectedIconColor = RubixCyan,
                selectedTextColor = RubixCyan
            ),
            modifier = Modifier.testTag("nav_home")
        )

        // VIRTUAL ANDROID
        NavigationBarItem(
            selected = selectedTab == MainTab.VIRTUAL_ANDROID,
            onClick = { onTabSelected(MainTab.VIRTUAL_ANDROID) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == MainTab.VIRTUAL_ANDROID) Icons.Filled.PhoneAndroid else Icons.Outlined.PhoneAndroid,
                    contentDescription = "Virtual Android"
                )
            },
            label = {
                Text(
                    text = "GUEST OS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (selectedTab == MainTab.VIRTUAL_ANDROID) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp
                    )
                )
            },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = RubixCyan.copy(alpha = 0.2f),
                selectedIconColor = RubixCyan,
                selectedTextColor = RubixCyan
            ),
            modifier = Modifier.testTag("nav_guest_os")
        )

        // FILES
        NavigationBarItem(
            selected = selectedTab == MainTab.FILES,
            onClick = { onTabSelected(MainTab.FILES) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == MainTab.FILES) Icons.Filled.Folder else Icons.Outlined.Folder,
                    contentDescription = "Files"
                )
            },
            label = {
                Text(
                    text = "FILES",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (selectedTab == MainTab.FILES) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp
                    )
                )
            },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = RubixCyan.copy(alpha = 0.2f),
                selectedIconColor = RubixCyan,
                selectedTextColor = RubixCyan
            ),
            modifier = Modifier.testTag("nav_files")
        )

        // TOOLS
        NavigationBarItem(
            selected = selectedTab == MainTab.TOOLS,
            onClick = { onTabSelected(MainTab.TOOLS) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == MainTab.TOOLS) Icons.Filled.Build else Icons.Outlined.Build,
                    contentDescription = "Tools"
                )
            },
            label = {
                Text(
                    text = "TOOLS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (selectedTab == MainTab.TOOLS) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp
                    )
                )
            },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = RubixCyan.copy(alpha = 0.2f),
                selectedIconColor = RubixCyan,
                selectedTextColor = RubixCyan
            ),
            modifier = Modifier.testTag("nav_tools")
        )

        // SETTINGS
        NavigationBarItem(
            selected = selectedTab == MainTab.SETTINGS,
            onClick = { onTabSelected(MainTab.SETTINGS) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == MainTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                    contentDescription = "Settings"
                )
            },
            label = {
                Text(
                    text = "SETTINGS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (selectedTab == MainTab.SETTINGS) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp
                    )
                )
            },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = RubixCyan.copy(alpha = 0.2f),
                selectedIconColor = RubixCyan,
                selectedTextColor = RubixCyan
            ),
            modifier = Modifier.testTag("nav_settings")
        )
    }
}
