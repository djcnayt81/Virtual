package com.example.ui.screens.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.VirtualInstanceEntity
import com.example.data.model.PerformanceMode
import com.example.data.model.SystemResourceStats
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.RubixAmber
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixGreen
import com.example.ui.theme.RubixMint
import com.example.ui.theme.RubixRed

@Composable
fun DashboardScreen(
    currentInstance: VirtualInstanceEntity?,
    instances: List<VirtualInstanceEntity>,
    resourceStats: SystemResourceStats,
    onStartInstance: () -> Unit,
    onStopInstance: () -> Unit,
    onSelectInstance: (String) -> Unit,
    onCreateInstance: (String, Int, Int, Int, Boolean) -> Unit,
    onCloneInstance: (String) -> Unit,
    onDeleteInstance: () -> Unit,
    onCreateSnapshot: (String, String) -> Unit,
    onToggleRoot: () -> Unit,
    onSetPerformanceMode: (PerformanceMode) -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToTools: () -> Unit,
    onNavigateToFiles: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var showCloneDialog by remember { mutableStateOf(false) }
    var showSnapshotDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card: Current Virtual Android 12 Instance
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(
                    1.dp,
                    if (currentInstance?.status == "RUNNING") RubixCyan.copy(alpha = 0.6f) else DarkSurfaceBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hero_instance_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // Header row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "MY VIRTUAL ANDROID",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = RubixCyan
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = currentInstance?.name ?: "Android 12 — Main",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black
                                ),
                                color = Color.White
                            )
                            Text(
                                text = currentInstance?.androidVersion ?: "Android 12 (API 31)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Running / Stopped Status Badge
                        val isRunning = currentInstance?.status == "RUNNING"
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isRunning) RubixMint.copy(alpha = 0.15f) else RubixAmber.copy(alpha = 0.15f),
                            border = BorderStroke(
                                1.dp,
                                if (isRunning) RubixMint.copy(alpha = 0.5f) else RubixAmber.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isRunning) RubixMint else RubixAmber)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isRunning) "RUNNING" else "STOPPED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = if (isRunning) RubixMint else RubixAmber
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Instance Specs Grid
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceElevated)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SpecItem(label = "RAM", value = "${(currentInstance?.ramMb ?: 3072) / 1024} GB")
                        SpecItem(label = "CPU", value = "${currentInstance?.cpuCores ?: 4} Cores")
                        SpecItem(label = "STORAGE", value = "${currentInstance?.storageGb ?: 16} GB")
                        SpecItem(label = "V-ROOT", value = if (currentInstance?.virtualRootEnabled == true) "ON" else "OFF")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Primary Action: START / STOP Button
                    if (currentInstance?.status == "RUNNING") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onStartInstance,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = RubixCyan,
                                    contentColor = Color(0xFF00363D)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("resume_guest_button")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("OPEN GUEST OS", fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = onStopInstance,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = RubixRed.copy(alpha = 0.2f),
                                    contentColor = RubixRed
                                ),
                                border = BorderStroke(1.dp, RubixRed.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("stop_guest_button")
                            ) {
                                Icon(Icons.Default.PowerSettingsNew, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("STOP", fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Button(
                            onClick = onStartInstance,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RubixCyan,
                                contentColor = Color(0xFF00363D)
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("start_guest_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "START ANDROID 12",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Secondary Action Buttons: SETTINGS | SNAPSHOT | BACKUP | DELETE
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ActionButton(
                            icon = Icons.Default.Settings,
                            label = "SETTINGS",
                            onClick = onNavigateToSettings
                        )
                        ActionButton(
                            icon = Icons.Default.CameraAlt,
                            label = "SNAPSHOT",
                            onClick = { showSnapshotDialog = true }
                        )
                        ActionButton(
                            icon = Icons.Default.ContentCopy,
                            label = "CLONE",
                            onClick = { showCloneDialog = true }
                        )
                        ActionButton(
                            icon = Icons.Default.Delete,
                            label = "DELETE",
                            onClick = { showDeleteConfirmDialog = true },
                            color = RubixRed
                        )
                    }
                }
            }
        }

        // Virtual Root Toggle Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (currentInstance?.virtualRootEnabled == true) RubixMint.copy(alpha = 0.15f)
                                    else DarkSurfaceElevated
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = if (currentInstance?.virtualRootEnabled == true) RubixMint else Color.Gray,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "VIRTUAL ROOT (GUEST ONLY)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = if (currentInstance?.virtualRootEnabled == true) "RUBIX VIRTUAL ROOT: ENABLED" else "RUBIX VIRTUAL ROOT: DISABLED",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = if (currentInstance?.virtualRootEnabled == true) RubixMint else Color.Gray
                            )
                        }
                    }

                    Switch(
                        checked = currentInstance?.virtualRootEnabled == true,
                        onCheckedChange = { onToggleRoot() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = RubixMint,
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.testTag("root_toggle_switch")
                    )
                }
            }
        }

        // Performance Mode Selector
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = RubixCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PERFORMANCE PROFILE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PerformanceMode.values().forEach { mode ->
                            val isSelected = (currentInstance?.performanceMode ?: "BALANCED") == mode.name
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) RubixCyan.copy(alpha = 0.15f) else DarkSurfaceElevated,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) RubixCyan else Color.Transparent
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onSetPerformanceMode(mode) }
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = mode.name.replace("_", " "),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 9.sp
                                        ),
                                        color = if (isSelected) RubixCyan else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live Resource Monitor Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "REAL-TIME RESOURCE MONITOR",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ResourceMetric(
                            icon = Icons.Default.Memory,
                            label = "CPU Load",
                            value = "${resourceStats.cpuLoadPercentage}%",
                            color = RubixCyan
                        )
                        ResourceMetric(
                            icon = Icons.Default.Storage,
                            label = "RAM Usage",
                            value = "${"%.1f".format(resourceStats.usedRamMb / 1024.0)} / 3.0 GB",
                            color = RubixMint
                        )
                        ResourceMetric(
                            icon = Icons.Default.Wifi,
                            label = "Virtual Net",
                            value = "${resourceStats.networkDownKbps.toInt()} KB/s",
                            color = RubixAmber
                        )
                    }
                }
            }
        }

        // Virtual Instances Section + "+ CREATE INSTANCE"
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "VIRTUAL INSTANCES (${instances.size})",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RubixCyan.copy(alpha = 0.15f),
                        contentColor = RubixCyan
                    ),
                    border = BorderStroke(1.dp, RubixCyan.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("create_instance_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "CREATE INSTANCE",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        items(instances) { inst ->
            val isCurrent = inst.id == currentInstance?.id
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (isCurrent) DarkSurfaceElevated else DarkSurfaceCard,
                border = BorderStroke(
                    1.dp,
                    if (isCurrent) RubixCyan.copy(alpha = 0.5f) else DarkSurfaceBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectInstance(inst.id) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = inst.name,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            if (inst.isDefault) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = RubixCyan.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "DEFAULT",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = RubixCyan,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${inst.androidVersion} • ${inst.ramMb / 1024}GB RAM • ${inst.cpuCores} Cores • ${inst.storageGb}GB",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Status pill
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (inst.status == "RUNNING") RubixMint.copy(alpha = 0.15f) else DarkBackground
                    ) {
                        Text(
                            text = inst.status,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            ),
                            color = if (inst.status == "RUNNING") RubixMint else Color.Gray,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // CREATE INSTANCE DIALOG
    if (showCreateDialog) {
        var newName by remember { mutableStateOf("Android 12 — ${listOf("Testing", "Gaming", "Dev", "Sandbox").random()}") }
        var selectedRam by remember { mutableStateOf(3072) }
        var selectedCores by remember { mutableStateOf(4) }
        var selectedStorage by remember { mutableStateOf(16) }
        var rootEnabled by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = {
                Text(
                    text = "CREATE ANDROID 12 INSTANCE",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = RubixCyan
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Instance Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "RAM Allocation: ${selectedRam / 1024} GB",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1024, 2048, 3072, 4096, 6144).forEach { ram ->
                            val sel = selectedRam == ram
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (sel) RubixCyan.copy(alpha = 0.2f) else DarkSurfaceElevated,
                                border = BorderStroke(1.dp, if (sel) RubixCyan else Color.Transparent),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedRam = ram }
                            ) {
                                Text(
                                    text = "${ram / 1024}G",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    ),
                                    color = if (sel) RubixCyan else Color.White,
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Text(
                        text = "CPU Cores: $selectedCores Cores",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1, 2, 4).forEach { core ->
                            val sel = selectedCores == core
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (sel) RubixCyan.copy(alpha = 0.2f) else DarkSurfaceElevated,
                                border = BorderStroke(1.dp, if (sel) RubixCyan else Color.Transparent),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedCores = core }
                            ) {
                                Text(
                                    text = "$core Core",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (sel) RubixCyan else Color.White,
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Text(
                        text = "Virtual Storage: $selectedStorage GB",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(8, 16, 32, 64).forEach { st ->
                            val sel = selectedStorage == st
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (sel) RubixCyan.copy(alpha = 0.2f) else DarkSurfaceElevated,
                                border = BorderStroke(1.dp, if (sel) RubixCyan else Color.Transparent),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedStorage = st }
                            ) {
                                Text(
                                    text = "${st}G",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (sel) RubixCyan else Color.White,
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Enable Virtual Root",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                        Switch(
                            checked = rootEnabled,
                            onCheckedChange = { rootEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = RubixMint
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateInstance(newName, selectedRam, selectedCores, selectedStorage, rootEnabled)
                        showCreateDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("CREATE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("CANCEL")
                }
            },
            containerColor = DarkSurfaceCard
        )
    }

    // CLONE DIALOG
    if (showCloneDialog) {
        var cloneName by remember { mutableStateOf("${currentInstance?.name ?: "Android 12"} (Clone)") }
        AlertDialog(
            onDismissRequest = { showCloneDialog = false },
            title = { Text("CLONE ANDROID 12 INSTANCE", color = RubixCyan) },
            text = {
                Column {
                    Text("Create an independent clone of '${currentInstance?.name}' with all packages and virtual storage:")
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = cloneName,
                        onValueChange = { cloneName = it },
                        label = { Text("Clone Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCloneInstance(cloneName)
                        showCloneDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("CLONE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCloneDialog = false }) { Text("CANCEL") }
            },
            containerColor = DarkSurfaceCard
        )
    }

    // SNAPSHOT DIALOG
    if (showSnapshotDialog) {
        var snapName by remember { mutableStateOf("Clean Android 12") }
        var snapDesc by remember { mutableStateOf("Initial setup snapshot") }
        AlertDialog(
            onDismissRequest = { showSnapshotDialog = false },
            title = { Text("CREATE SNAPSHOT", color = RubixCyan) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Capture instant state of '${currentInstance?.name}' for quick recovery:")
                    OutlinedTextField(
                        value = snapName,
                        onValueChange = { snapName = it },
                        label = { Text("Snapshot Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = snapDesc,
                        onValueChange = { snapDesc = it },
                        label = { Text("Description") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateSnapshot(snapName, snapDesc)
                        showSnapshotDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("SAVE SNAPSHOT", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSnapshotDialog = false }) { Text("CANCEL") }
            },
            containerColor = DarkSurfaceCard
        )
    }

    // DELETE CONFIRM DIALOG
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("DELETE INSTANCE", color = RubixRed) },
            text = {
                Text("Are you sure you want to delete '${currentInstance?.name}'? All guest applications, app data, and virtual storage will be removed.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteInstance()
                        showDeleteConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixRed)
                ) {
                    Text("DELETE", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) { Text("CANCEL") }
            },
            containerColor = DarkSurfaceCard
        )
    }
}

@Composable
private fun SpecItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            ),
            color = Color.White
        )
    }
}

@Composable
private fun ActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    color: Color = RubixCyan
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = color,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 9.sp
            ),
            color = Color.White
        )
    }
}

@Composable
private fun ResourceMetric(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkSurfaceElevated)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            ),
            color = Color.White
        )
    }
}
