package com.example.ui.screens.guest.apps

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GetApp
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.VirtualAppEntity
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.MonetGreen
import com.example.ui.theme.MonetPeach
import com.example.ui.theme.MonetSky
import com.example.ui.theme.MonetYellow
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixMint

data class SampleApk(
    val name: String,
    val packageName: String,
    val version: String,
    val description: String,
    val sizeMb: Double,
    val iconKey: String,
    val category: String
)

@Composable
fun VirtualPackageInstallerScreen(
    installedApps: List<VirtualAppEntity>,
    onInstallSampleApk: (String, String, String, String, Double) -> Unit,
    onInstallCustomApk: (String, String, Double) -> Unit,
    onCloseApp: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showCustomInstallDialog by remember { mutableStateOf(false) }

    val sampleApkRepository = listOf(
        SampleApk(
            name = "SysBench 12",
            packageName = "com.rubix.sysbench",
            version = "2.4.0",
            description = "Virtual CPU, RAM, & 3D GPU Stress Benchmark for Android 12",
            sizeMb = 34.5,
            iconKey = "calculator",
            category = "Utilities"
        ),
        SampleApk(
            name = "Root Explorer Lite",
            packageName = "com.rubix.rootexplorer",
            version = "5.1.0",
            description = "Virtual root filesystem navigation for /system, /data & /apex",
            sizeMb = 12.8,
            iconKey = "files",
            category = "Root Tools"
        ),
        SampleApk(
            name = "CPU-Z Virtual",
            packageName = "com.rubix.cpuz",
            version = "1.8.2",
            description = "Inspect virtual SoC, ARM64 cores, thermal zones & guest sensors",
            sizeMb = 8.4,
            iconKey = "terminal",
            category = "System"
        ),
        SampleApk(
            name = "NetSpeed 12",
            packageName = "com.rubix.netspeed",
            version = "3.0.1",
            description = "Virtual socket & network throughput monitor",
            sizeMb = 6.2,
            iconKey = "browser",
            category = "Network"
        ),
        SampleApk(
            name = "Retro Arcade 12",
            packageName = "com.rubix.retroarcade",
            version = "1.0.0",
            description = "60 FPS Hardware-accelerated sample guest game",
            sizeMb = 48.0,
            iconKey = "music",
            category = "Games"
        )
    )

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceCard)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCloseApp) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "Package Installer",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = "Zero-ADB Internal Package Manager",
                            style = MaterialTheme.typography.labelSmall,
                            color = RubixMint
                        )
                    }
                }

                Button(
                    onClick = { showCustomInstallDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RubixCyan.copy(alpha = 0.15f),
                        contentColor = RubixCyan
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("INSTALL APK", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Divider(color = DarkSurfaceBorder)

            // Zero-ADB Info Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                border = BorderStroke(1.dp, RubixMint.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = RubixMint, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ZERO-ADB INSTALLATION PROTOCOL",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = RubixMint
                        )
                        Text(
                            text = "APKs are parsed and deployed directly into the Android 12 sandbox without host ADB permissions.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // APK Repository List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "VIRTUAL APP STORE / APK REPOSITORY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                items(sampleApkRepository) { apk ->
                    val isInstalled = installedApps.any { it.packageName == apk.packageName }
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                        border = BorderStroke(1.dp, DarkSurfaceBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkSurfaceElevated),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Android,
                                        contentDescription = null,
                                        tint = if (isInstalled) RubixMint else RubixCyan,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = apk.name,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    Text(
                                        text = apk.description,
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2
                                    )
                                    Text(
                                        text = "${apk.version} • ${apk.sizeMb} MB • ${apk.category}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 9.sp
                                        ),
                                        color = RubixCyan
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            if (isInstalled) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = RubixMint.copy(alpha = 0.15f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = RubixMint, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("INSTALLED", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = RubixMint)
                                    }
                                }
                            } else {
                                Button(
                                    onClick = {
                                        onInstallSampleApk(
                                            apk.name,
                                            apk.packageName,
                                            apk.version,
                                            apk.iconKey,
                                            apk.sizeMb
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = RubixCyan,
                                        contentColor = Color(0xFF00363D)
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("INSTALL", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // CUSTOM APK INSTALL DIALOG
    if (showCustomInstallDialog) {
        var apkName by remember { mutableStateOf("CustomApp") }
        var apkPackage by remember { mutableStateOf("com.example.customapp") }
        var apkSize by remember { mutableStateOf(24.0) }

        AlertDialog(
            onDismissRequest = { showCustomInstallDialog = false },
            title = { Text("Install Custom APK", color = RubixCyan) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select or enter package metadata to install into guest Android 12:")
                    OutlinedTextField(
                        value = apkName,
                        onValueChange = { apkName = it },
                        label = { Text("Application Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = apkPackage,
                        onValueChange = { apkPackage = it },
                        label = { Text("Package Name (e.g. com.dev.myapp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (apkName.isNotBlank() && apkPackage.isNotBlank()) {
                            onInstallCustomApk(apkName.trim(), apkPackage.trim(), apkSize)
                            showCustomInstallDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("DEPLOY APK", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomInstallDialog = false }) { Text("CANCEL") }
            },
            containerColor = DarkSurfaceCard
        )
    }
}
