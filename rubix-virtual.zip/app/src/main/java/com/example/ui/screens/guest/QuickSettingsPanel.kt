package com.example.ui.screens.guest

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.VirtualInstanceEntity
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.MonetGreen
import com.example.ui.theme.MonetPeach
import com.example.ui.theme.MonetSky
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixMint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun QuickSettingsPanel(
    instance: VirtualInstanceEntity,
    onToggleRoot: () -> Unit,
    onOpenSettings: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var wifiEnabled by remember { mutableStateOf(instance.virtualInternet) }
    var bluetoothEnabled by remember { mutableStateOf(true) }
    var flashlightEnabled by remember { mutableStateOf(false) }
    var autoRotateEnabled by remember { mutableStateOf(true) }
    var micPassthrough by remember { mutableStateOf(instance.micAccess) }
    var cameraPassthrough by remember { mutableStateOf(instance.cameraAccess) }
    var brightness by remember { mutableStateOf(0.75f) }

    val timeFormat = SimpleDateFormat("h:mm", Locale.getDefault())
    val dateFormat = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
    val now = Date()

    Surface(
        color = Color(0xFF141A24).copy(alpha = 0.98f),
        shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Header: Time, Date, Battery, Settings icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = timeFormat.format(now),
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = dateFormat.format(now),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            onClose()
                            onOpenSettings()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Guest Settings",
                            tint = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Brightness Slider
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.BrightnessMedium,
                    contentDescription = null,
                    tint = MonetSky,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Slider(
                    value = brightness,
                    onValueChange = { brightness = it },
                    colors = SliderDefaults.colors(
                        thumbColor = MonetSky,
                        activeTrackColor = MonetSky,
                        inactiveTrackColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Android 12 Large Quick Settings Tiles (2 columns x 4 rows)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Column 1
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickTile(
                        icon = Icons.Default.Wifi,
                        label = "Internet",
                        subLabel = if (wifiEnabled) "Virtual Bridge" else "Disconnected",
                        isActive = wifiEnabled,
                        activeColor = MonetSky,
                        onClick = { wifiEnabled = !wifiEnabled }
                    )
                    QuickTile(
                        icon = Icons.Default.Security,
                        label = "Virtual Root",
                        subLabel = if (instance.virtualRootEnabled) "Enabled (UID 0)" else "Disabled",
                        isActive = instance.virtualRootEnabled,
                        activeColor = RubixMint,
                        onClick = onToggleRoot
                    )
                    QuickTile(
                        icon = Icons.Default.CameraAlt,
                        label = "Camera Pass",
                        subLabel = if (cameraPassthrough) "Authorized" else "Blocked",
                        isActive = cameraPassthrough,
                        activeColor = MonetGreen,
                        onClick = { cameraPassthrough = !cameraPassthrough }
                    )
                    QuickTile(
                        icon = Icons.Default.DarkMode,
                        label = "Dark theme",
                        subLabel = "Snow Cone",
                        isActive = true,
                        activeColor = MonetPeach,
                        onClick = {}
                    )
                }

                // Column 2
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickTile(
                        icon = Icons.Default.Bluetooth,
                        label = "Bluetooth",
                        subLabel = if (bluetoothEnabled) "On" else "Off",
                        isActive = bluetoothEnabled,
                        activeColor = MonetSky,
                        onClick = { bluetoothEnabled = !bluetoothEnabled }
                    )
                    QuickTile(
                        icon = Icons.Default.FlashlightOn,
                        label = "Flashlight",
                        subLabel = if (flashlightEnabled) "On" else "Off",
                        isActive = flashlightEnabled,
                        activeColor = MonetPeach,
                        onClick = { flashlightEnabled = !flashlightEnabled }
                    )
                    QuickTile(
                        icon = Icons.Default.Mic,
                        label = "Mic Access",
                        subLabel = if (micPassthrough) "Authorized" else "Blocked",
                        isActive = micPassthrough,
                        activeColor = MonetGreen,
                        onClick = { micPassthrough = !micPassthrough }
                    )
                    QuickTile(
                        icon = Icons.Default.ScreenRotation,
                        label = "Auto-rotate",
                        subLabel = if (autoRotateEnabled) "Dynamic" else "Portrait",
                        isActive = autoRotateEnabled,
                        activeColor = MonetPeach,
                        onClick = { autoRotateEnabled = !autoRotateEnabled }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Pull up handle
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClose() }
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 40.dp, height = 4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.Gray.copy(alpha = 0.5f))
                )
            }
        }
    }
}

@Composable
private fun QuickTile(
    icon: ImageVector,
    label: String,
    subLabel: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isActive) activeColor else DarkSurfaceElevated,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isActive) Color.White.copy(alpha = 0.25f) else Color.Gray.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isActive) Color(0xFF102027) else Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (isActive) Color(0xFF102027) else Color.White,
                    maxLines = 1
                )
                Text(
                    text = subLabel,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = if (isActive) Color(0xFF263238) else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}
