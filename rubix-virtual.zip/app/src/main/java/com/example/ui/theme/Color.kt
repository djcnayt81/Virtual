package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cybernetic / Dark Tech Palette for RUBIX VIRTUAL
val RubixCyan = Color(0xFF00E5FF)
val RubixCyanGlow = Color(0xFF80F0FF)
val RubixMint = Color(0xFF00E676)
val RubixGreen = Color(0xFF3DDC84) // Android 12 signature green
val RubixAmber = Color(0xFFFFB300)
val RubixRed = Color(0xFFFF5252)
val RubixPurple = Color(0xFF7C4DFF)

// Background & Surface Tokens
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceElevated = Color(0xFF1A2333)
val DarkSurfaceCard = Color(0xFF151E2E)
val DarkSurfaceBorder = Color(0xFF26354D)

val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFE2E8F0)
val LightSurfaceCard = Color(0xFFFFFFFF)
val LightSurfaceBorder = Color(0xFFCBD5E1)

// Android 12 Guest Monet Material You Accent Colors
val MonetGreen = Color(0xFF81C784)
val MonetGreenDark = Color(0xFF1B5E20)
val MonetPeach = Color(0xFFFFCC80)
val MonetLavender = Color(0xFFCE93D8)
val MonetSky = Color(0xFF90CAF9)
val MonetYellow = Color(0xFFFFF59D)
