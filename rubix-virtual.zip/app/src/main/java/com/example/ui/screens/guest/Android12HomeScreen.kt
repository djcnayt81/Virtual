package com.example.ui.screens.guest

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GetApp
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.VirtualAppEntity
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.MonetGreen
import com.example.ui.theme.MonetPeach
import com.example.ui.theme.MonetSky
import com.example.ui.theme.MonetYellow
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixMint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun Android12HomeScreen(
    apps: List<VirtualAppEntity>,
    wallpaperIndex: Int,
    isAppDrawerOpen: Boolean,
    onLaunchApp: (VirtualAppEntity) -> Unit,
    onToggleAppDrawer: () -> Unit,
    onCloseAppDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val wallpaperGradients = listOf(
        // 0: Deep Aurora (Android 12 default style)
        Brush.verticalGradient(listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364))),
        // 1: Emerald Cyber
        Brush.verticalGradient(listOf(Color(0xFF001A14), Color(0xFF00382B), Color(0xFF00523F))),
        // 2: Cyber Titanium Night
        Brush.verticalGradient(listOf(Color(0xFF0B0F19), Color(0xFF161F30), Color(0xFF1E293B))),
        // 3: Sunset Peach
        Brush.verticalGradient(listOf(Color(0xFF2B1055), Color(0xFF7597DE), Color(0xFF2B1055)))
    )

    val currentBg = wallpaperGradients[wallpaperIndex.coerceIn(0, wallpaperGradients.lastIndex)]
    val timeFormat = SimpleDateFormat("h:mm", Locale.getDefault())
    val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
    val now = Date()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(currentBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Section: Android 12 Material You Clock & Date Widget
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.Black.copy(alpha = 0.25f),
                    modifier = Modifier.padding(horizontal = 12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                    ) {
                        Text(
                            text = timeFormat.format(now),
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = (-1).sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = dateFormat.format(now),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium
                            ),
                            color = MonetSky
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Android 12 Search Bar Pill Widget
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color.Black.copy(alpha = 0.35f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clickable {
                            val browserApp = apps.find { it.packageName == "com.android.browser" }
                            if (browserApp != null) onLaunchApp(browserApp)
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "G",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black
                                ),
                                color = RubixCyan
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Search apps, files & web...",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Search",
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Middle Section: Home Grid Icons (4 columns)
            val homeScreenApps = apps.take(8)
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(homeScreenApps) { app ->
                    AppGridItem(app = app, onClick = { onLaunchApp(app) })
                }
            }

            // Bottom Section: Dock (4 fixed apps + App Drawer toggle)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Swipe-up / App Drawer indicator
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onToggleAppDrawer() }
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 32.dp, height = 4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.White.copy(alpha = 0.6f))
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Dock Bar
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = Color.Black.copy(alpha = 0.35f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val browser = apps.find { it.packageName == "com.android.browser" }
                        val files = apps.find { it.packageName == "com.android.documentsui" }
                        val terminal = apps.find { it.packageName == "com.rubix.terminal" }
                        val settings = apps.find { it.packageName == "com.android.settings" }

                        if (browser != null) DockItem(app = browser, onClick = { onLaunchApp(browser) })
                        if (files != null) DockItem(app = files, onClick = { onLaunchApp(files) })

                        // Central App Drawer Button
                        DockIconButton(
                            icon = Icons.Default.Apps,
                            label = "Apps",
                            color = RubixCyan,
                            onClick = onToggleAppDrawer
                        )

                        if (terminal != null) DockItem(app = terminal, onClick = { onLaunchApp(terminal) })
                        if (settings != null) DockItem(app = settings, onClick = { onLaunchApp(settings) })
                    }
                }
            }
        }

        // FULL APP DRAWER OVERLAY
        AnimatedVisibility(
            visible = isAppDrawerOpen,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            AppDrawerOverlay(
                apps = apps,
                onLaunchApp = onLaunchApp,
                onClose = onCloseAppDrawer
            )
        }
    }
}

@Composable
private fun AppDrawerOverlay(
    apps: List<VirtualAppEntity>,
    onLaunchApp: (VirtualAppEntity) -> Unit,
    onClose: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredApps = apps.filter {
        it.appName.contains(searchQuery, ignoreCase = true) || it.packageName.contains(searchQuery, ignoreCase = true)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A).copy(alpha = 0.96f))
            .clickable(enabled = false) {}
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 16.dp)
        ) {
            // Search Bar in App Drawer
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search ${apps.size} installed apps...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RubixCyan) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = RubixCyan,
                    unfocusedBorderColor = Color.Gray.copy(alpha = 0.3f),
                    focusedContainerColor = DarkSurfaceElevated,
                    unfocusedContainerColor = DarkSurfaceElevated
                ),
                shape = RoundedCornerShape(24.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("app_drawer_search")
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "ALL APPLICATIONS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                ),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredApps) { app ->
                    AppGridItem(app = app, onClick = { onLaunchApp(app) })
                }
            }

            // Close Handle
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClose() }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SWIPE DOWN TO CLOSE",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
private fun AppGridItem(
    app: VirtualAppEntity,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(4.dp)
    ) {
        val (icon, tintColor, bgColor) = getAppVisuals(app.iconKey)

        Surface(
            shape = RoundedCornerShape(18.dp),
            color = bgColor,
            shadowElevation = 4.dp,
            modifier = Modifier.size(54.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = app.appName,
                    tint = tintColor,
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = app.appName,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp
            ),
            color = Color.White,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun DockItem(
    app: VirtualAppEntity,
    onClick: () -> Unit
) {
    val (icon, tintColor, bgColor) = getAppVisuals(app.iconKey)
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = bgColor,
        modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = app.appName,
                tint = tintColor,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun DockIconButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = DarkSurfaceElevated,
        modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

private fun getAppVisuals(iconKey: String): Triple<ImageVector, Color, Color> {
    return when (iconKey) {
        "settings" -> Triple(Icons.Default.Settings, Color(0xFF263238), MonetSky)
        "files" -> Triple(Icons.Default.Folder, Color(0xFF003919), MonetGreen)
        "browser" -> Triple(Icons.Default.Language, Color(0xFF002B4D), MonetSky)
        "camera" -> Triple(Icons.Default.CameraAlt, Color(0xFF452B00), MonetPeach)
        "gallery" -> Triple(Icons.Default.PhotoLibrary, Color(0xFF3700B3), Color(0xFFE1BEE7))
        "terminal" -> Triple(Icons.Default.Terminal, RubixCyan, Color(0xFF090D16))
        "music" -> Triple(Icons.Default.MusicNote, Color(0xFF880E4F), Color(0xFFF8BBD0))
        "calculator" -> Triple(Icons.Default.Calculate, Color(0xFFE65100), MonetYellow)
        "notes" -> Triple(Icons.Default.EditNote, Color(0xFF1B5E20), MonetGreen)
        "clock" -> Triple(Icons.Default.Schedule, Color(0xFF004D40), MonetSky)
        "packageinstaller" -> Triple(Icons.Default.GetApp, Color(0xFF004D40), RubixMint)
        else -> Triple(Icons.Default.Description, Color.White, DarkSurfaceElevated)
    }
}
