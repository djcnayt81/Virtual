package com.example.ui.screens.guest.apps

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.VirtualFileEntity
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.MonetGreen
import com.example.ui.theme.MonetPeach
import com.example.ui.theme.MonetSky
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixRed

@Composable
fun VirtualFileManagerScreen(
    files: List<VirtualFileEntity>,
    onCreateFolder: (String, String) -> Unit,
    onCreateTextFile: (String, String, String) -> Unit,
    onDeleteFile: (VirtualFileEntity) -> Unit,
    onCloseApp: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentPath by remember { mutableStateOf("/storage/emulated/0") }
    var searchQuery by remember { mutableStateOf("") }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var selectedFileForViewing by remember { mutableStateOf<VirtualFileEntity?>(null) }

    val currentDirectoryFiles = files.filter { file ->
        val parent = if (file.path.contains('/')) file.path.substringBeforeLast('/') else "/storage/emulated/0"
        val effectiveParent = if (parent.isEmpty()) "/storage/emulated/0" else parent
        effectiveParent == currentPath || file.path == "$currentPath/${file.name}"
    }.filter { it.name.contains(searchQuery, ignoreCase = true) }
        .sortedWith(compareByDescending<VirtualFileEntity> { it.isDirectory }.thenBy { it.name })

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceCard)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (currentPath == "/storage/emulated/0" || currentPath == "/") {
                                onCloseApp()
                            } else {
                                val parent = currentPath.substringBeforeLast('/', "/storage/emulated/0")
                                currentPath = if (parent.isEmpty()) "/storage/emulated/0" else parent
                            }
                        }
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Files (Android 12)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = currentPath,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = RubixCyan,
                            maxLines = 1
                        )
                    }

                    IconButton(onClick = { showNewFolderDialog = true }) {
                        Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder", tint = MonetGreen)
                    }
                    IconButton(onClick = { showNewFileDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "New File", tint = RubixCyan)
                    }
                }

                Divider(color = DarkSurfaceBorder)

                // Quick Navigation Shortcuts (Android, DCIM, Download, Music, Documents)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ShortcutPill(label = "Internal", icon = Icons.Default.Home) { currentPath = "/storage/emulated/0" }
                    ShortcutPill(label = "Download", icon = Icons.Default.Folder) { currentPath = "/storage/emulated/0/Download" }
                    ShortcutPill(label = "DCIM", icon = Icons.Default.Image) { currentPath = "/storage/emulated/0/DCIM" }
                    ShortcutPill(label = "Music", icon = Icons.Default.MusicNote) { currentPath = "/storage/emulated/0/Music" }
                }

                // File List
                if (currentDirectoryFiles.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Folder, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("This folder is empty", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(currentDirectoryFiles) { file ->
                            FileListItem(
                                file = file,
                                onClick = {
                                    if (file.isDirectory) {
                                        currentPath = file.path
                                    } else {
                                        selectedFileForViewing = file
                                    }
                                },
                                onDelete = { onDeleteFile(file) }
                            )
                        }
                    }
                }
            }
        }
    }

    // CREATE FOLDER DIALOG
    if (showNewFolderDialog) {
        var folderName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("New Folder", color = RubixCyan) },
            text = {
                OutlinedTextField(
                    value = folderName,
                    onValueChange = { folderName = it },
                    label = { Text("Folder Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (folderName.isNotBlank()) {
                            onCreateFolder(currentPath, folderName.trim())
                            showNewFolderDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("CREATE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { showNewFolderDialog = false }) { Text("CANCEL") } },
            containerColor = DarkSurfaceCard
        )
    }

    // CREATE FILE DIALOG
    if (showNewFileDialog) {
        var fileName by remember { mutableStateOf("note.txt") }
        var fileContent by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFileDialog = false },
            title = { Text("New Text File", color = RubixCyan) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = fileName,
                        onValueChange = { fileName = it },
                        label = { Text("File Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = fileContent,
                        onValueChange = { fileContent = it },
                        label = { Text("Content") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (fileName.isNotBlank()) {
                            onCreateTextFile(currentPath, fileName.trim(), fileContent)
                            showNewFileDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("SAVE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { showNewFileDialog = false }) { Text("CANCEL") } },
            containerColor = DarkSurfaceCard
        )
    }

    // FILE VIEWER DIALOG
    if (selectedFileForViewing != null) {
        val file = selectedFileForViewing!!
        AlertDialog(
            onDismissRequest = { selectedFileForViewing = null },
            title = { Text(file.name, color = RubixCyan) },
            text = {
                Column {
                    Text(
                        text = "Path: ${file.path}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceElevated,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    ) {
                        Text(
                            text = file.textContent ?: "[Binary Content: ${file.sizeBytes} bytes]",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = Color.White,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedFileForViewing = null },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("CLOSE", color = Color(0xFF00363D))
                }
            },
            containerColor = DarkSurfaceCard
        )
    }
}

@Composable
private fun ShortcutPill(label: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = DarkSurfaceElevated,
        border = BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = RubixCyan, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp), color = Color.White)
        }
    }
}

@Composable
private fun FileListItem(
    file: VirtualFileEntity,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSurfaceCard,
        border = BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = when {
                        file.isDirectory -> Icons.Default.Folder
                        file.name.endsWith(".apk") -> Icons.Default.Description
                        file.name.endsWith(".jpg") || file.name.endsWith(".png") -> Icons.Default.Image
                        file.name.endsWith(".mp4") -> Icons.Default.Movie
                        file.name.endsWith(".mp3") -> Icons.Default.MusicNote
                        else -> Icons.Default.Description
                    },
                    contentDescription = null,
                    tint = if (file.isDirectory) MonetGreen else RubixCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = file.name,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        text = if (file.isDirectory) "Folder" else "${file.sizeBytes} B • ${file.mimeType}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
        }
    }
}
