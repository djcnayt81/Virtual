package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FloatingGuestWindow
import com.example.ui.components.RubixBottomNav
import com.example.ui.components.RubixTopBar
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.files.HostGuestTransferScreen
import com.example.ui.screens.guest.VirtualAndroidScreen
import com.example.ui.screens.settings.HostAppSettingsScreen
import com.example.ui.screens.tools.VirtualToolsScreen
import com.example.ui.screens.welcome.WelcomeCompatibilityScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RubixCyan
import com.example.ui.theme.RubixMint
import com.example.viewmodel.GuestDisplayMode
import com.example.viewmodel.MainTab
import com.example.viewmodel.RubixViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: RubixViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                RubixApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun RubixApp(viewModel: RubixViewModel) {
    val compatibilityReport by viewModel.compatibilityReport.collectAsState()
    val hasCompletedWelcome by viewModel.hasCompletedWelcome.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val currentInstance by viewModel.currentInstance.collectAsState()
    val instances by viewModel.instances.collectAsState()
    val currentInstanceApps by viewModel.currentInstanceApps.collectAsState()
    val currentInstanceFiles by viewModel.currentInstanceFiles.collectAsState()
    val currentInstanceSnapshots by viewModel.currentInstanceSnapshots.collectAsState()
    val bootLogs by viewModel.bootLogs.collectAsState()
    val bootProgress by viewModel.bootProgress.collectAsState()
    val isBooting by viewModel.isBooting.collectAsState()
    val activeApp by viewModel.activeApp.collectAsState()
    val recentApps by viewModel.recentApps.collectAsState()
    val resourceStats by viewModel.resourceStats.collectAsState()
    val displayMode by viewModel.displayMode.collectAsState()
    val isQuickSettingsOpen by viewModel.isQuickSettingsOpen.collectAsState()
    val isRecentAppsOpen by viewModel.isRecentAppsOpen.collectAsState()
    val isAppDrawerOpen by viewModel.isAppDrawerOpen.collectAsState()
    val transferState by viewModel.transferState.collectAsState()
    val terminalLines by viewModel.terminalLines.collectAsState()
    val statusBannerMessage by viewModel.statusBannerMessage.collectAsState()

    var showInfoDialog by remember { mutableStateOf(false) }

    // If welcome & compatibility flow hasn't been completed yet
    if (!hasCompletedWelcome) {
        WelcomeCompatibilityScreen(
            report = compatibilityReport,
            onCreateVirtualAndroid = {
                viewModel.completeWelcome()
            }
        )
        return
    }

    Box(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
        Scaffold(
            topBar = {
                // Show host top bar on dashboard, files, tools, and settings tabs
                if (selectedTab != MainTab.VIRTUAL_ANDROID || displayMode == GuestDisplayMode.FLOATING_WINDOW) {
                    RubixTopBar(
                        currentInstance = currentInstance,
                        resourceStats = resourceStats,
                        onToggleRoot = { viewModel.toggleVirtualRoot() },
                        onInfoClick = { showInfoDialog = true }
                    )
                }
            },
            bottomBar = {
                RubixBottomNav(
                    selectedTab = selectedTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            },
            containerColor = DarkBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    MainTab.HOME -> {
                        DashboardScreen(
                            currentInstance = currentInstance,
                            instances = instances,
                            resourceStats = resourceStats,
                            onStartInstance = { viewModel.startCurrentInstance() },
                            onStopInstance = { viewModel.stopCurrentInstance() },
                            onSelectInstance = { viewModel.selectInstance(it) },
                            onCreateInstance = { name, ram, cores, st, root ->
                                viewModel.createInstance(name, ram, cores, st, root)
                            },
                            onCloneInstance = { viewModel.cloneCurrentInstance(it) },
                            onDeleteInstance = { viewModel.deleteCurrentInstance() },
                            onCreateSnapshot = { name, desc -> viewModel.createSnapshot(name, desc) },
                            onToggleRoot = { viewModel.toggleVirtualRoot() },
                            onSetPerformanceMode = { viewModel.setPerformanceMode(it) },
                            onNavigateToSettings = { viewModel.selectTab(MainTab.SETTINGS) },
                            onNavigateToTools = { viewModel.selectTab(MainTab.TOOLS) },
                            onNavigateToFiles = { viewModel.selectTab(MainTab.FILES) }
                        )
                    }

                    MainTab.VIRTUAL_ANDROID -> {
                        if (displayMode == GuestDisplayMode.FULLSCREEN) {
                            VirtualAndroidScreen(
                                instance = currentInstance,
                                apps = currentInstanceApps,
                                files = currentInstanceFiles,
                                bootLogs = bootLogs,
                                bootProgress = bootProgress,
                                isBooting = isBooting,
                                activeApp = activeApp,
                                recentApps = recentApps,
                                displayMode = displayMode,
                                isQuickSettingsOpen = isQuickSettingsOpen,
                                isRecentAppsOpen = isRecentAppsOpen,
                                isAppDrawerOpen = isAppDrawerOpen,
                                terminalLines = terminalLines,
                                onStartInstance = { viewModel.startCurrentInstance() },
                                onStopInstance = { viewModel.stopCurrentInstance() },
                                onToggleRoot = { viewModel.toggleVirtualRoot() },
                                onSetWallpaper = { viewModel.setWallpaper(it) },
                                onLaunchApp = { viewModel.launchApp(it) },
                                onCloseActiveApp = { viewModel.closeActiveApp() },
                                onToggleRecentApps = { viewModel.toggleRecentApps() },
                                onCloseRecentApps = { viewModel.closeRecentApps() },
                                onClearAllRecentApps = { viewModel.clearAllRecentApps() },
                                onRemoveRecentApp = { viewModel.removeRecentApp(it) },
                                onToggleAppDrawer = { viewModel.toggleAppDrawer() },
                                onCloseAppDrawer = { viewModel.closeAppDrawer() },
                                onToggleQuickSettings = { viewModel.toggleQuickSettings() },
                                onCloseQuickSettings = { viewModel.closeQuickSettings() },
                                onSetDisplayMode = { viewModel.setDisplayMode(it) },
                                onForceStopApp = { viewModel.forceStopApp(it) },
                                onClearAppCache = { viewModel.clearAppCache(it) },
                                onClearAppData = { viewModel.clearAppData(it) },
                                onUninstallApp = { viewModel.uninstallApp(it) },
                                onToggleAppRoot = { viewModel.toggleAppRootPermission(it) },
                                onInstallSampleApk = { n, p, v, i, s -> viewModel.installSampleApk(n, p, v, i, s) },
                                onInstallCustomApk = { n, p, s -> viewModel.installImportedApk(n, p, s) },
                                onCreateFolder = { p, n -> viewModel.createVirtualFolder(p, n) },
                                onCreateTextFile = { p, n, c -> viewModel.createVirtualTextFile(p, n, c) },
                                onDeleteFile = { viewModel.deleteVirtualFile(it) },
                                onExecuteTerminalCommand = { viewModel.executeTerminalCommand(it) }
                            )
                        } else {
                            // On floating mode, show Dashboard behind and floating window on top
                            DashboardScreen(
                                currentInstance = currentInstance,
                                instances = instances,
                                resourceStats = resourceStats,
                                onStartInstance = { viewModel.startCurrentInstance() },
                                onStopInstance = { viewModel.stopCurrentInstance() },
                                onSelectInstance = { viewModel.selectInstance(it) },
                                onCreateInstance = { name, ram, cores, st, root ->
                                    viewModel.createInstance(name, ram, cores, st, root)
                                },
                                onCloneInstance = { viewModel.cloneCurrentInstance(it) },
                                onDeleteInstance = { viewModel.deleteCurrentInstance() },
                                onCreateSnapshot = { name, desc -> viewModel.createSnapshot(name, desc) },
                                onToggleRoot = { viewModel.toggleVirtualRoot() },
                                onSetPerformanceMode = { viewModel.setPerformanceMode(it) },
                                onNavigateToSettings = { viewModel.selectTab(MainTab.SETTINGS) },
                                onNavigateToTools = { viewModel.selectTab(MainTab.TOOLS) },
                                onNavigateToFiles = { viewModel.selectTab(MainTab.FILES) }
                            )
                        }
                    }

                    MainTab.FILES -> {
                        HostGuestTransferScreen(
                            files = currentInstanceFiles,
                            transferState = transferState,
                            onSimulateTransfer = { name, isImport, onDone ->
                                viewModel.simulateFileTransfer(name, isImport, onDone)
                            }
                        )
                    }

                    MainTab.TOOLS -> {
                        VirtualToolsScreen(
                            currentInstance = currentInstance,
                            snapshots = currentInstanceSnapshots,
                            onCreateSnapshot = { name, desc -> viewModel.createSnapshot(name, desc) },
                            onRestoreSnapshot = { viewModel.restoreSnapshot(it) },
                            onDeleteSnapshot = { viewModel.deleteSnapshot(it) },
                            onShowBanner = { viewModel.showBanner(it) }
                        )
                    }

                    MainTab.SETTINGS -> {
                        HostAppSettingsScreen(
                            currentInstance = currentInstance,
                            displayMode = displayMode,
                            onSetDisplayMode = { viewModel.setDisplayMode(it) },
                            onRerunCompatibility = { viewModel.showWelcomeAgain() },
                            onShowBanner = { viewModel.showBanner(it) }
                        )
                    }
                }

                // PiP Floating Window Overlay if in Floating Mode
                if (displayMode == GuestDisplayMode.FLOATING_WINDOW) {
                    FloatingGuestWindow(
                        onExpandToFullscreen = { viewModel.setDisplayMode(GuestDisplayMode.FULLSCREEN) },
                        onCloseFloating = { viewModel.setDisplayMode(GuestDisplayMode.FULLSCREEN) }
                    ) {
                        VirtualAndroidScreen(
                            instance = currentInstance,
                            apps = currentInstanceApps,
                            files = currentInstanceFiles,
                            bootLogs = bootLogs,
                            bootProgress = bootProgress,
                            isBooting = isBooting,
                            activeApp = activeApp,
                            recentApps = recentApps,
                            displayMode = displayMode,
                            isQuickSettingsOpen = isQuickSettingsOpen,
                            isRecentAppsOpen = isRecentAppsOpen,
                            isAppDrawerOpen = isAppDrawerOpen,
                            terminalLines = terminalLines,
                            onStartInstance = { viewModel.startCurrentInstance() },
                            onStopInstance = { viewModel.stopCurrentInstance() },
                            onToggleRoot = { viewModel.toggleVirtualRoot() },
                            onSetWallpaper = { viewModel.setWallpaper(it) },
                            onLaunchApp = { viewModel.launchApp(it) },
                            onCloseActiveApp = { viewModel.closeActiveApp() },
                            onToggleRecentApps = { viewModel.toggleRecentApps() },
                            onCloseRecentApps = { viewModel.closeRecentApps() },
                            onClearAllRecentApps = { viewModel.clearAllRecentApps() },
                            onRemoveRecentApp = { viewModel.removeRecentApp(it) },
                            onToggleAppDrawer = { viewModel.toggleAppDrawer() },
                            onCloseAppDrawer = { viewModel.closeAppDrawer() },
                            onToggleQuickSettings = { viewModel.toggleQuickSettings() },
                            onCloseQuickSettings = { viewModel.closeQuickSettings() },
                            onSetDisplayMode = { viewModel.setDisplayMode(it) },
                            onForceStopApp = { viewModel.forceStopApp(it) },
                            onClearAppCache = { viewModel.clearAppCache(it) },
                            onClearAppData = { viewModel.clearAppData(it) },
                            onUninstallApp = { viewModel.uninstallApp(it) },
                            onToggleAppRoot = { viewModel.toggleAppRootPermission(it) },
                            onInstallSampleApk = { n, p, v, i, s -> viewModel.installSampleApk(n, p, v, i, s) },
                            onInstallCustomApk = { n, p, s -> viewModel.installImportedApk(n, p, s) },
                            onCreateFolder = { p, n -> viewModel.createVirtualFolder(p, n) },
                            onCreateTextFile = { p, n, c -> viewModel.createVirtualTextFile(p, n, c) },
                            onDeleteFile = { viewModel.deleteVirtualFile(it) },
                            onExecuteTerminalCommand = { viewModel.executeTerminalCommand(it) }
                        )
                    }
                }
            }
        }

        // Live Status Banner / Toast
        AnimatedVisibility(
            visible = statusBannerMessage != null,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 48.dp, start = 16.dp, end = 16.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(1.dp, RubixCyan),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = RubixCyan, modifier = Modifier.size(18.dp))
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = statusBannerMessage ?: "",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White
                    )
                }
            }
        }
    }

    // System Info Dialog
    if (showInfoDialog) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = {
                Text(
                    text = "RUBIX VIRTUAL ARCHITECTURE",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = RubixCyan
                )
            },
            text = {
                androidx.compose.foundation.layout.Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Zero Wi-Fi Debugging / Zero Wireless ADB Required.",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = RubixMint
                    )
                    Text(
                        text = "• Guest OS: Android 12 Snow Cone (API 31)\n• Userland Native Sandboxing Engine\n• Host Root: Not Required\n• Virtual Root: Permissive Guest UID 0 Only\n• Local Offline Storage: SQLite & Room",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        lineHeight = 20.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showInfoDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RubixCyan)
                ) {
                    Text("OK", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkSurfaceCard
        )
    }
}
