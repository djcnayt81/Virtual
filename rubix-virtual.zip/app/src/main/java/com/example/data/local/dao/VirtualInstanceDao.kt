package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.VirtualInstanceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VirtualInstanceDao {
    @Query("SELECT * FROM virtual_instances ORDER BY createdAt ASC")
    fun getAllInstances(): Flow<List<VirtualInstanceEntity>>

    @Query("SELECT * FROM virtual_instances WHERE id = :id LIMIT 1")
    suspend fun getInstanceById(id: String): VirtualInstanceEntity?

    @Query("SELECT * FROM virtual_instances WHERE id = :id LIMIT 1")
    fun observeInstanceById(id: String): Flow<VirtualInstanceEntity?>

    @Query("SELECT * FROM virtual_instances WHERE status = 'RUNNING' LIMIT 1")
    fun getRunningInstance(): Flow<VirtualInstanceEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstance(instance: VirtualInstanceEntity)

    @Update
    suspend fun updateInstance(instance: VirtualInstanceEntity)

    @Query("UPDATE virtual_instances SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("UPDATE virtual_instances SET virtualRootEnabled = :enabled WHERE id = :id")
    suspend fun updateVirtualRoot(id: String, enabled: Boolean)

    @Query("UPDATE virtual_instances SET performanceMode = :mode WHERE id = :id")
    suspend fun updatePerformanceMode(id: String, mode: String)

    @Query("UPDATE virtual_instances SET wallpaperIndex = :index WHERE id = :id")
    suspend fun updateWallpaper(id: String, index: Int)

    @Query("UPDATE virtual_instances SET status = 'STOPPED'")
    suspend fun stopAllInstances()

    @Query("DELETE FROM virtual_instances WHERE id = :id")
    suspend fun deleteInstance(id: String)
}
