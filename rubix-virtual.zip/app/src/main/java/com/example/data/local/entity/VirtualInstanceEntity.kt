package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "virtual_instances")
data class VirtualInstanceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val androidVersion: String = "Android 12 (API 31 - Snow Cone)",
    val buildId: String = "SQ3A.220705.004",
    val status: String = "STOPPED", // STOPPED, RUNNING, PAUSED, STARTING
    val ramMb: Int = 3072,
    val cpuCores: Int = 4,
    val storageGb: Int = 16,
    val virtualRootEnabled: Boolean = true,
    val performanceMode: String = "BALANCED", // PERFORMANCE, BALANCED, BATTERY_SAVER
    val resolutionWidth: Int = 1080,
    val resolutionHeight: Int = 2340,
    val dpi: Int = 420,
    val orientation: String = "PORTRAIT", // PORTRAIT, LANDSCAPE, AUTO
    val virtualInternet: Boolean = true,
    val cameraAccess: Boolean = true,
    val micAccess: Boolean = true,
    val audioOutput: Boolean = true,
    val clipboardSync: Boolean = true,
    val wallpaperIndex: Int = 0,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastBootedAt: Long = 0L
)
