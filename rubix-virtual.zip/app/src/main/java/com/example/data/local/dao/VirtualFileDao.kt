package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.VirtualFileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VirtualFileDao {
    @Query("SELECT * FROM virtual_files WHERE instanceId = :instanceId ORDER BY isDirectory DESC, name ASC")
    fun getFilesByInstance(instanceId: String): Flow<List<VirtualFileEntity>>

    @Query("SELECT * FROM virtual_files WHERE instanceId = :instanceId AND path = :path LIMIT 1")
    suspend fun getFileByPath(instanceId: String, path: String): VirtualFileEntity?

    @Query("SELECT * FROM virtual_files WHERE instanceId = :instanceId AND id = :id LIMIT 1")
    suspend fun getFileById(instanceId: String, id: String): VirtualFileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFile(file: VirtualFileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFiles(files: List<VirtualFileEntity>)

    @Update
    suspend fun updateFile(file: VirtualFileEntity)

    @Query("DELETE FROM virtual_files WHERE instanceId = :instanceId AND path = :path")
    suspend fun deleteByPath(instanceId: String, path: String)

    @Query("DELETE FROM virtual_files WHERE instanceId = :instanceId AND id = :id")
    suspend fun deleteById(instanceId: String, id: String)

    @Query("DELETE FROM virtual_files WHERE instanceId = :instanceId")
    suspend fun deleteFilesByInstance(instanceId: String)
}
