package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.VirtualAppDao
import com.example.data.local.dao.VirtualFileDao
import com.example.data.local.dao.VirtualInstanceDao
import com.example.data.local.dao.VirtualSnapshotDao
import com.example.data.local.entity.VirtualAppEntity
import com.example.data.local.entity.VirtualFileEntity
import com.example.data.local.entity.VirtualInstanceEntity
import com.example.data.local.entity.VirtualSnapshotEntity

@Database(
    entities = [
        VirtualInstanceEntity::class,
        VirtualAppEntity::class,
        VirtualFileEntity::class,
        VirtualSnapshotEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RubixDatabase : RoomDatabase() {
    abstract fun instanceDao(): VirtualInstanceDao
    abstract fun appDao(): VirtualAppDao
    abstract fun fileDao(): VirtualFileDao
    abstract fun snapshotDao(): VirtualSnapshotDao

    companion object {
        @Volatile
        private var INSTANCE: RubixDatabase? = null

        fun getDatabase(context: Context): RubixDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RubixDatabase::class.java,
                    "rubix_virtual_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
