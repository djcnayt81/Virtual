package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "virtual_snapshots")
data class VirtualSnapshotEntity(
    @PrimaryKey val id: String,
    val instanceId: String,
    val name: String,
    val description: String = "",
    val sizeMb: Double = 120.0,
    val appsCount: Int = 10,
    val filesCount: Int = 15,
    val createdAt: Long = System.currentTimeMillis()
)
