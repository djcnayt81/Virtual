package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.VirtualSnapshotEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VirtualSnapshotDao {
    @Query("SELECT * FROM virtual_snapshots WHERE instanceId = :instanceId ORDER BY createdAt DESC")
    fun getSnapshotsByInstance(instanceId: String): Flow<List<VirtualSnapshotEntity>>

    @Query("SELECT * FROM virtual_snapshots WHERE id = :id LIMIT 1")
    suspend fun getSnapshotById(id: String): VirtualSnapshotEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: VirtualSnapshotEntity)

    @Query("DELETE FROM virtual_snapshots WHERE id = :id")
    suspend fun deleteSnapshot(id: String)

    @Query("DELETE FROM virtual_snapshots WHERE instanceId = :instanceId")
    suspend fun deleteSnapshotsByInstance(instanceId: String)
}
