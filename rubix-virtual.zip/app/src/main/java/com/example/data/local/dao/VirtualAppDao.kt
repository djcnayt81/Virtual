package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.VirtualAppEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VirtualAppDao {
    @Query("SELECT * FROM virtual_apps WHERE instanceId = :instanceId ORDER BY isSystemApp DESC, appName ASC")
    fun getAppsByInstance(instanceId: String): Flow<List<VirtualAppEntity>>

    @Query("SELECT * FROM virtual_apps WHERE instanceId = :instanceId AND packageName = :packageName LIMIT 1")
    suspend fun getApp(instanceId: String, packageName: String): VirtualAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: VirtualAppEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApps(apps: List<VirtualAppEntity>)

    @Update
    suspend fun updateApp(app: VirtualAppEntity)

    @Query("UPDATE virtual_apps SET isRunning = :isRunning WHERE instanceId = :instanceId AND packageName = :packageName")
    suspend fun setAppRunning(instanceId: String, packageName: String, isRunning: Boolean)

    @Query("UPDATE virtual_apps SET cacheSizeMb = 0.0 WHERE instanceId = :instanceId AND packageName = :packageName")
    suspend fun clearAppCache(instanceId: String, packageName: String)

    @Query("UPDATE virtual_apps SET dataSizeMb = 0.5, cacheSizeMb = 0.0 WHERE instanceId = :instanceId AND packageName = :packageName")
    suspend fun clearAppData(instanceId: String, packageName: String)

    @Query("UPDATE virtual_apps SET rootAccessGranted = :granted WHERE instanceId = :instanceId AND packageName = :packageName")
    suspend fun updateRootPermission(instanceId: String, packageName: String, granted: Boolean)

    @Query("UPDATE virtual_apps SET grantedPermissions = :permissions WHERE instanceId = :instanceId AND packageName = :packageName")
    suspend fun updatePermissions(instanceId: String, packageName: String, permissions: String)

    @Query("DELETE FROM virtual_apps WHERE instanceId = :instanceId AND packageName = :packageName")
    suspend fun deleteApp(instanceId: String, packageName: String)

    @Query("DELETE FROM virtual_apps WHERE instanceId = :instanceId")
    suspend fun deleteAppsByInstance(instanceId: String)
}
