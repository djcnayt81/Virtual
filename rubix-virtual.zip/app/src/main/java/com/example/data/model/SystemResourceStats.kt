package com.example.data.model

data class CompatibilityReport(
    val cpuArch: String,
    val cpuCores: Int,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val totalStorageGb: Long,
    val availableStorageGb: Long,
    val hostAndroidVersion: String,
    val hostSdkInt: Int,
    val gpuRenderer: String,
    val isArm64OrX86_64: Boolean,
    val hasSufficientRam: Boolean,
    val hasSufficientStorage: Boolean,
    val virtualizationSupported: Boolean,
    val isOverallCompatible: Boolean,
    val recommendedRamMb: Int,
    val recommendedCores: Int,
    val recommendedStorageGb: Int,
    val statusMessage: String
)

data class SystemResourceStats(
    val cpuLoadPercentage: Int = 24,
    val usedRamMb: Int = 1840,
    val totalAllocatedRamMb: Int = 3072,
    val usedStorageMb: Long = 4200,
    val totalAllocatedStorageMb: Long = 16384,
    val networkDownKbps: Double = 124.5,
    val networkUpKbps: Double = 32.1,
    val batteryTemperatureC: Float = 33.5f,
    val fps: Int = 60
)

enum class PerformanceMode(val title: String, val description: String) {
    PERFORMANCE("Performance Mode", "Maximum guest CPU allocation, 60fps rendering, uncapped scheduler"),
    BALANCED("Balanced Mode", "Dynamic CPU scaling, balanced RAM usage, thermal throttling protection"),
    BATTERY_SAVER("Battery Saver", "Throttled background cycles, reduced animations, 30fps rendering")
}
