package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "virtual_apps")
data class VirtualAppEntity(
    @PrimaryKey val id: String,
    val instanceId: String,
    val packageName: String,
    val appName: String,
    val versionName: String = "1.0.0",
    val versionCode: Int = 1,
    val iconKey: String, // settings, files, browser, camera, gallery, terminal, music, calculator, notes, clock, packageinstaller, custom
    val isSystemApp: Boolean = false,
    val apkPath: String = "",
    val dataSizeMb: Double = 12.5,
    val cacheSizeMb: Double = 4.2,
    val isRunning: Boolean = false,
    val grantedPermissions: String = "INTERNET,CAMERA,STORAGE,AUDIO",
    val rootAccessGranted: Boolean = false,
    val installedAt: Long = System.currentTimeMillis()
)
