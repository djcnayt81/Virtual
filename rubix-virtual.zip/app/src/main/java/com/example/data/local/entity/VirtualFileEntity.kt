package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "virtual_files")
data class VirtualFileEntity(
    @PrimaryKey val id: String,
    val instanceId: String,
    val path: String, // e.g. /Download, /DCIM/Camera/IMG_01.jpg
    val name: String,
    val isDirectory: Boolean = false,
    val sizeBytes: Long = 0L,
    val mimeType: String = "*/*",
    val textContent: String? = null,
    val localUri: String? = null,
    val lastModified: Long = System.currentTimeMillis()
)
